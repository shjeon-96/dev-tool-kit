import { forwardRef, type ComponentProps, type ComponentRef } from "react";
import { Popover as HeroPopover } from "heroui-native/popover";
import { FadeIn, FadeOut, ReduceMotion } from "react-native-reanimated";
import { metrics } from "../generated/tokens";

type PopoverContentProps = ComponentProps<typeof HeroPopover.Content>;
const contentAnimation = {
  entering: FadeIn.duration(metrics.duration.fast).reduceMotion(
    ReduceMotion.System,
  ),
  exiting: FadeOut.duration(metrics.duration.fast).reduceMotion(
    ReduceMotion.System,
  ),
} satisfies NonNullable<PopoverContentProps["animation"]>;

const Content = forwardRef<
  ComponentRef<typeof HeroPopover.Content>,
  PopoverContentProps
>((props, ref) => {
  if (props.presentation !== "popover")
    return <HeroPopover.Content ref={ref} {...props} />;
  const { animation, ...rest } = props;
  return (
    <HeroPopover.Content
      ref={ref}
      {...rest}
      animation={animation ?? contentAnimation}
    />
  );
});

Content.displayName = "PixelLogicPopoverContent";

export const Popover = Object.assign(HeroPopover, { Content });
