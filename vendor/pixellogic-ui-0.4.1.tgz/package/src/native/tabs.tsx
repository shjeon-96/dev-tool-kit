import { forwardRef, type ComponentProps, type ComponentRef } from "react";
import { Tabs as HeroTabs, useTabsMeasurements } from "heroui-native/tabs";
import { tv } from "tailwind-variants";
import { metrics } from "../generated/tokens";

const rootStyles = tv({ base: "w-full min-w-0" });
const listStyles = tv({ base: "w-full self-stretch" });
const triggerStyles = tv({
  base: "min-w-0 px-2",
  variants: { scrollable: { true: "flex-none", false: "flex-1" } },
});
const labelStyles = tv({ base: "shrink text-center" });
const indicatorAnimation = {
  width: { type: "timing", config: { duration: metrics.duration.fast } },
  height: { type: "timing", config: { duration: metrics.duration.fast } },
  translateX: { type: "timing", config: { duration: metrics.duration.fast } },
} as const;
const separatorAnimation = {
  opacity: {
    value: [0, 1] as [number, number],
    timingConfig: { duration: metrics.duration.fast },
  },
};

const Root = forwardRef<
  ComponentRef<typeof HeroTabs>,
  ComponentProps<typeof HeroTabs>
>(({ className, ...props }, ref) => (
  <HeroTabs ref={ref} className={rootStyles({ className })} {...props} />
));
const List = forwardRef<
  ComponentRef<typeof HeroTabs.List>,
  ComponentProps<typeof HeroTabs.List>
>(({ className, accessibilityLabel = "탭 목록", ...props }, ref) => (
  <HeroTabs.List
    ref={ref}
    accessibilityLabel={accessibilityLabel}
    className={listStyles({ className })}
    {...props}
  />
));
const Trigger = forwardRef<
  ComponentRef<typeof HeroTabs.Trigger>,
  ComponentProps<typeof HeroTabs.Trigger>
>(({ className, ...props }, ref) => {
  const { isScrollView } = useTabsMeasurements();
  // 스크롤을 명시한 목록은 항목의 고유 너비를 유지해요.
  return (
    <HeroTabs.Trigger
      ref={ref}
      className={triggerStyles({ scrollable: isScrollView, className })}
      {...props}
    />
  );
});
const Label = forwardRef<
  ComponentRef<typeof HeroTabs.Label>,
  ComponentProps<typeof HeroTabs.Label>
>(({ className, ...props }, ref) => (
  <HeroTabs.Label ref={ref} className={labelStyles({ className })} {...props} />
));
const Indicator = forwardRef<
  ComponentRef<typeof HeroTabs.Indicator>,
  ComponentProps<typeof HeroTabs.Indicator>
>(({ animation = indicatorAnimation, ...props }, ref) => (
  <HeroTabs.Indicator ref={ref} animation={animation} {...props} />
));
const Separator = forwardRef<
  ComponentRef<typeof HeroTabs.Separator>,
  ComponentProps<typeof HeroTabs.Separator>
>(({ animation = separatorAnimation, ...props }, ref) => (
  <HeroTabs.Separator ref={ref} animation={animation} {...props} />
));

Root.displayName = "PixelLogicTabs";
List.displayName = "PixelLogicTabsList";
Trigger.displayName = "PixelLogicTabsTrigger";
Label.displayName = "PixelLogicTabsLabel";
Indicator.displayName = "PixelLogicTabsIndicator";
Separator.displayName = "PixelLogicTabsSeparator";

export const Tabs = Object.assign(Root, {
  List,
  Trigger,
  Label,
  ListBackground: HeroTabs.ListBackground,
  ScrollView: HeroTabs.ScrollView,
  Indicator,
  Separator,
  Content: HeroTabs.Content,
});
