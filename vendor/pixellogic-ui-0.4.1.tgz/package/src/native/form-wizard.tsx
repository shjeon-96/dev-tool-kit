import { useEffect, useRef, type ReactNode } from "react";
import { Keyboard } from "react-native";
import { useToast } from "heroui-native/toast";
import Animated, { FadeIn, ReduceMotion } from "react-native-reanimated";
import { metrics } from "../generated/tokens";
import { useWizard, type WizardOptions } from "../shared/use-wizard";
import { Stepper } from "./stepper";
import { BrandState, Button, Stack } from "./components";
import { withBrandErrorBoundary } from "./error-boundary";
export interface FormWizardProps extends Omit<WizardOptions, "stepCount"> {
  steps: { id: string; title: string; content: ReactNode }[];
  submitLabel?: string;
  failureMessage?: string;
  completedContent?: ReactNode;
}
function FormWizardView({
  steps,
  submitLabel = "저장해요",
  failureMessage = "저장하지 못했어요. 다시 시도해 주세요.",
  completedContent,
  onError,
  ...options
}: FormWizardProps) {
  const { toast } = useToast();
  const wizard = useWizard({
    ...options,
    stepCount: steps.length,
    onError: (error) => {
      toast.show({ label: failureMessage, variant: "danger" });
      onError?.(error);
    },
  });
  const previousStep = useRef(wizard.current);
  useEffect(() => {
    // 검증에 실패한 동안에는 키보드를 유지하고, 실제 단계가 바뀔 때만
    // 다음 콘텐츠와 CTA가 키보드 아래로 밀리지 않게 닫아요.
    if (
      (previousStep.current !== wizard.current || wizard.completed) &&
      Keyboard.isVisible()
    )
      Keyboard.dismiss();
    previousStep.current = wizard.current;
  }, [wizard.current, wizard.completed]);
  if (wizard.completed)
    return completedContent ?? <BrandState kind="success" title="저장했어요" />;
  return (
    <Stack gap="xl">
      <Stepper
        steps={steps.map((step) => step.title)}
        current={wizard.current}
      />
      <Animated.View
        key={steps[wizard.current]?.id}
        collapsable={false}
        entering={FadeIn.duration(metrics.duration.fast).reduceMotion(
          ReduceMotion.System,
        )}
      >
        {steps[wizard.current]?.content}
      </Animated.View>
      <Stack direction="row">
        <Button
          variant="outline"
          isDisabled={wizard.current === 0 || wizard.busy}
          onPress={() => {
            if (Keyboard.isVisible()) Keyboard.dismiss();
            wizard.previous();
          }}
        >
          이전으로 가요
        </Button>
        <Button isLoading={wizard.busy} onPress={() => void wizard.next()}>
          {wizard.current === steps.length - 1 ? submitLabel : "다음으로 가요"}
        </Button>
      </Stack>
    </Stack>
  );
}

export const FormWizard = withBrandErrorBoundary(
  FormWizardView,
  "단계를 진행할 수 없어요",
);
