import { forwardRef, type ComponentProps, type ComponentRef } from "react";
import { Toast as HeroToast } from "heroui-native/toast";

type ToastCloseProps = ComponentProps<typeof HeroToast.Close>;

const Close = forwardRef<ComponentRef<typeof HeroToast.Close>, ToastCloseProps>(
  ({ "aria-label": ariaLabel, accessibilityLabel, ...props }, ref) => {
    const label = accessibilityLabel ?? ariaLabel ?? "알림을 닫아요";
    return (
      <HeroToast.Close
        ref={ref}
        aria-label={ariaLabel ?? label}
        accessibilityLabel={label}
        {...props}
      />
    );
  },
);

Close.displayName = "PixelLogicToastClose";

export const Toast = Object.assign(HeroToast, { Close });
