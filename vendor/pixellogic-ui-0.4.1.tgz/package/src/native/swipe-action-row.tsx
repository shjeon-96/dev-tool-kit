import {
  createContext,
  useContext,
  useRef,
  type ReactNode,
  type RefObject,
} from "react";
import { Pressable, StyleSheet, View } from "react-native";
import ReanimatedSwipeable, {
  type SwipeableMethods,
} from "react-native-gesture-handler/ReanimatedSwipeable";
import type { LucideIcon } from "lucide-react-native";
import { metrics } from "../generated/tokens";
import type { ListRowContract } from "../shared/contracts";
import { BrandText, Icon, ListRow } from "./components";
import { useReducedMotionSetting, useTheme } from "./provider";

export interface SwipeAction {
  label: string;
  icon: LucideIcon;
  onPress: () => void;
}

export interface SwipeActionRowProps extends ListRowContract {
  onPress?: () => void;
  actions?: { destructive?: SwipeAction };
}

// 열린 행을 하나로 유지하는 controller예요. Provider가 없으면 행마다 독립 동작해요.
const OpenRowContext = createContext<{
  claim: (row: RefObject<SwipeableMethods | null>) => void;
  release: (row: RefObject<SwipeableMethods | null>) => void;
} | null>(null);

export function SwipeActionRowGroup({ children }: { children: ReactNode }) {
  const open = useRef<RefObject<SwipeableMethods | null> | null>(null);
  return (
    <OpenRowContext.Provider
      value={{
        claim: (row) => {
          if (open.current && open.current !== row)
            open.current.current?.close();
          open.current = row;
        },
        release: (row) => {
          if (open.current === row) open.current = null;
        },
      }}
    >
      {children}
    </OpenRowContext.Provider>
  );
}

/**
 * 스와이프로 파괴적 동작을 여는 목록 행이에요.
 *
 * 삭제 확인은 이 컴포넌트가 소유하지 않아요. `onPress`를 받은 호출부가
 * 확인 절차를 책임지므로 Alert가 두 번 뜨지 않습니다.
 */
export function SwipeActionRow({
  actions,
  onPress,
  ...row
}: SwipeActionRowProps) {
  const { colors } = useTheme();
  const reducedMotion = useReducedMotionSetting();
  const group = useContext(OpenRowContext);
  const swipeable = useRef<SwipeableMethods>(null);
  const destructive = actions?.destructive;

  if (!destructive) return <ListRow {...row} onPress={onPress} />;

  function runDestructive() {
    swipeable.current?.close();
    destructive?.onPress();
  }

  return (
    <ReanimatedSwipeable
      ref={swipeable}
      friction={2}
      enabled={!row.disabled}
      // 움직임을 줄인 환경에서는 즉시 열고 닫되 동작 자체는 그대로 남겨요.
      animationOptions={
        reducedMotion ? { duration: 0, dampingRatio: 1 } : undefined
      }
      onSwipeableWillOpen={() => group?.claim(swipeable)}
      onSwipeableClose={() => group?.release(swipeable)}
      renderRightActions={() => (
        <Pressable
          onPress={runDestructive}
          accessibilityRole="button"
          accessibilityLabel={`${row.title} ${destructive.label}`}
          style={[styles.action, { backgroundColor: colors.dangerSoft }]}
        >
          {/* 색만으로 구분하지 않도록 아이콘과 문구를 함께 둬요. */}
          <Icon icon={destructive.icon} color={colors.danger} />
          <BrandText variant="label" style={{ color: colors.danger }}>
            {destructive.label}
          </BrandText>
        </Pressable>
      )}
    >
      <View style={{ backgroundColor: colors.background }}>
        <ListRow {...row} onPress={onPress} />
      </View>
    </ReanimatedSwipeable>
  );
}

const styles = StyleSheet.create({
  action: {
    width: metrics.size.control * 2,
    minHeight: metrics.size.row,
    alignItems: "center",
    justifyContent: "center",
    gap: metrics.space.xs,
  },
});
