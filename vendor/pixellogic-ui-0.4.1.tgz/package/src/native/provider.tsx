import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import { AccessibilityInfo, StyleSheet } from "react-native";
import {
  HeroUINativeProvider,
  type HeroUINativeConfig,
} from "heroui-native/provider";
import type { ToastRootAnimation } from "heroui-native/toast";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { Uniwind, useUniwind } from "uniwind";
import { colors } from "../generated/tokens";
import { metrics } from "../generated/tokens";
import { FadeIn, FadeOut, ReduceMotion } from "react-native-reanimated";
export type ThemeMode = "light" | "dark" | "system";
const ReducedMotionContext = createContext(false);

export function useReducedMotionSetting() {
  return useContext(ReducedMotionContext);
}

export function useTheme() {
  const { theme, hasAdaptiveThemes } = useUniwind();
  const resolvedMode = theme === "dark" ? "dark" : "light";
  return {
    mode: hasAdaptiveThemes ? "system" : resolvedMode,
    resolvedMode,
    colors: colors[resolvedMode],
    setMode: (mode: ThemeMode) => Uniwind.setTheme(mode),
  } as const;
}
export function PixelLogicProvider({
  children,
  mode,
  config,
}: {
  children: ReactNode;
  mode?: ThemeMode;
  config?: HeroUINativeConfig;
}) {
  const [reducedMotion, setReducedMotion] = useState(false);
  const toastAnimation = {
    entering: {
      top: FadeIn.duration(metrics.duration.normal).reduceMotion(
        ReduceMotion.System,
      ),
      bottom: FadeIn.duration(metrics.duration.normal).reduceMotion(
        ReduceMotion.System,
      ),
    },
    exiting: {
      top: FadeOut.duration(metrics.duration.fast).reduceMotion(
        ReduceMotion.System,
      ),
      bottom: FadeOut.duration(metrics.duration.fast).reduceMotion(
        ReduceMotion.System,
      ),
    },
    opacity: { timingConfig: { duration: metrics.duration.fast } },
    translateY: { timingConfig: { duration: metrics.duration.normal } },
    scale: { timingConfig: { duration: metrics.duration.fast } },
  } satisfies ToastRootAnimation;
  useEffect(() => {
    let active = true;
    AccessibilityInfo.isReduceMotionEnabled().then((value) => {
      if (active) setReducedMotion(value);
    });
    const listener = AccessibilityInfo.addEventListener(
      "reduceMotionChanged",
      setReducedMotion,
    );
    return () => {
      active = false;
      listener.remove();
    };
  }, []);
  useEffect(() => {
    if (mode) Uniwind.setTheme(mode);
  }, [mode]);
  const nativeConfig = config ?? {};
  const devInfo = {
    stylingPrinciples: false,
    ...nativeConfig.devInfo,
  };
  const configuredToast =
    typeof nativeConfig.toast === "object" ? nativeConfig.toast : undefined;
  const toast =
    nativeConfig.toast === false || nativeConfig.toast === "disabled"
      ? nativeConfig.toast
      : {
          ...configuredToast,
          defaultProps: {
            ...configuredToast?.defaultProps,
            animation:
              configuredToast?.defaultProps?.animation ?? toastAnimation,
          },
        };
  return (
    <GestureHandlerRootView style={styles.root}>
      <SafeAreaProvider>
        <ReducedMotionContext.Provider value={reducedMotion}>
          <HeroUINativeProvider
            config={{
              ...nativeConfig,
              animation: reducedMotion ? "disable-all" : nativeConfig.animation,
              devInfo,
              textProps: { allowFontScaling: true, ...nativeConfig.textProps },
              toast,
            }}
          >
            {children}
          </HeroUINativeProvider>
        </ReducedMotionContext.Provider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
const styles = StyleSheet.create({ root: { flex: 1 } });
