import { forwardRef, type ComponentProps, type ComponentRef } from "react";
import { Dialog as HeroDialog } from "heroui-native/dialog";
import { FadeIn, FadeOut, ReduceMotion } from "react-native-reanimated";
import { metrics } from "../generated/tokens";

type DialogContentProps = ComponentProps<typeof HeroDialog.Content>;
type DialogPortalProps = ComponentProps<typeof HeroDialog.Portal>;

const contentAnimation = {
  entering: FadeIn.duration(metrics.duration.normal).reduceMotion(
    ReduceMotion.System,
  ),
  exiting: FadeOut.duration(metrics.duration.fast).reduceMotion(
    ReduceMotion.System,
  ),
} satisfies NonNullable<DialogContentProps["animation"]>;

const Content = forwardRef<
  ComponentRef<typeof HeroDialog.Content>,
  DialogContentProps
>(({ animation = contentAnimation, ...props }, ref) => (
  <HeroDialog.Content ref={ref} animation={animation} {...props} />
));

Content.displayName = "PixelLogicDialogContent";

const Portal = ({
  unstable_accessibilityContainerViewIsModal = true,
  ...props
}: DialogPortalProps) => (
  <HeroDialog.Portal
    unstable_accessibilityContainerViewIsModal={
      unstable_accessibilityContainerViewIsModal
    }
    {...props}
  />
);

Portal.displayName = "PixelLogicDialogPortal";

export const Dialog = Object.assign(HeroDialog, { Content, Portal });
