import type { ComponentType, ReactNode } from "react";
import {
  DEFAULT_ERROR_DESCRIPTION,
  ErrorBoundary,
} from "../shared/error-boundary";
import { BrandState, Button } from "./components";

export {
  ErrorBoundary,
  type ErrorBoundaryProps,
} from "../shared/error-boundary";

export function BrandErrorBoundary({
  title,
  children,
  onError,
  onRetry,
}: {
  title: string;
  children: ReactNode;
  onError?: (error: Error) => void;
  onRetry?: () => void;
}) {
  function retry(reset: () => void) {
    onRetry?.();
    reset();
  }
  return (
    <ErrorBoundary
      onError={onError}
      fallback={(_, reset) => (
        <BrandState
          kind="error"
          title={title}
          description={DEFAULT_ERROR_DESCRIPTION}
          compact
          action={<Button onPress={() => retry(reset)}>다시 시도해요</Button>}
        />
      )}
    >
      {children}
    </ErrorBoundary>
  );
}

// 데이터가 어긋나면 화면 전체를 잃는 대신 해당 컴포넌트 자리만 오류 상태로 바꿔요.
export function withBrandErrorBoundary<P extends object>(
  Component: ComponentType<P>,
  title: string,
) {
  function Guarded(props: P) {
    return (
      <BrandErrorBoundary title={title}>
        <Component {...props} />
      </BrandErrorBoundary>
    );
  }
  Guarded.displayName = `Guarded(${Component.displayName ?? Component.name})`;
  return Guarded;
}
