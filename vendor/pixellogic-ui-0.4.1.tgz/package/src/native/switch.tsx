import { forwardRef, type ComponentProps, type ComponentRef } from "react";
import { Switch as HeroSwitch } from "heroui-native/switch";
import { metrics } from "../generated/tokens";

type SwitchProps = ComponentProps<typeof HeroSwitch>;
type SwitchThumbProps = ComponentProps<typeof HeroSwitch.Thumb>;

const rootAnimation = {
  scale: { timingConfig: { duration: metrics.duration.fast } },
  backgroundColor: { timingConfig: { duration: metrics.duration.normal } },
} satisfies NonNullable<SwitchProps["animation"]>;

const thumbAnimation = {
  backgroundColor: { timingConfig: { duration: metrics.duration.normal } },
} satisfies NonNullable<SwitchThumbProps["animation"]>;

const Root = forwardRef<ComponentRef<typeof HeroSwitch>, SwitchProps>(
  ({ animation = rootAnimation, ...props }, ref) => (
    <HeroSwitch ref={ref} animation={animation} {...props} />
  ),
);

Root.displayName = "PixelLogicSwitch";

const Thumb = forwardRef<
  ComponentRef<typeof HeroSwitch.Thumb>,
  SwitchThumbProps
>(({ animation = thumbAnimation, ...props }, ref) => (
  <HeroSwitch.Thumb ref={ref} animation={animation} {...props} />
));

Thumb.displayName = "PixelLogicSwitchThumb";

export const Switch = Object.assign(Root, {
  Thumb,
  StartContent: HeroSwitch.StartContent,
  EndContent: HeroSwitch.EndContent,
  Background: HeroSwitch.Background,
});
