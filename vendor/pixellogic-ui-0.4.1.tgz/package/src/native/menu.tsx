import { forwardRef, type ComponentProps, type ComponentRef } from "react";
import { Menu as HeroMenu } from "heroui-native/menu";
import { FadeIn, FadeOut, ReduceMotion } from "react-native-reanimated";
import { metrics } from "../generated/tokens";

type MenuContentProps = ComponentProps<typeof HeroMenu.Content>;
type MenuPopoverContentProps = Extract<
  MenuContentProps,
  { presentation: "popover" }
>;

const popoverAnimation = {
  entering: FadeIn.duration(metrics.duration.fast).reduceMotion(
    ReduceMotion.System,
  ),
  exiting: FadeOut.duration(metrics.duration.fast).reduceMotion(
    ReduceMotion.System,
  ),
} satisfies NonNullable<MenuPopoverContentProps["animation"]>;

const Content = forwardRef<
  ComponentRef<typeof HeroMenu.Content>,
  MenuContentProps
>((props, ref) => {
  if (props.presentation === "bottom-sheet")
    return <HeroMenu.Content ref={ref} {...props} />;

  const { animation, ...rest } = props;
  return (
    <HeroMenu.Content
      ref={ref}
      {...rest}
      animation={animation ?? popoverAnimation}
    />
  );
});

Content.displayName = "PixelLogicMenuContent";

export const Menu = Object.assign(HeroMenu, { Content });
