import { useEffect, useState } from "react";
import { Platform, ScrollView, StyleSheet, View } from "react-native";
import DateTimePicker, {
  DateTimePickerAndroid,
} from "@react-native-community/datetimepicker";
import { Select } from "./select";
import { Dialog } from "./dialog";
import { Label } from "heroui-native/label";
import { Description } from "heroui-native/description";
import { FieldError } from "heroui-native/field-error";
import { TextField as HeroTextField } from "heroui-native/text-field";
import { InputOTP } from "./input-otp";
import { Slider } from "heroui-native/slider";
import { CalendarDays, X } from "lucide-react-native";
import { metrics } from "../generated/tokens";
import type { ComboboxContract } from "../shared/contracts";
import {
  parseLocalDate,
  toLocalDate,
  displayDate,
  validateChoices,
} from "../shared/date";
import { BrandText, Button, Icon, Stack, TextField } from "./components";
import { useTheme } from "./provider";
import { withBrandErrorBoundary } from "./error-boundary";

function ComboboxView({
  label,
  options,
  value,
  onValueChange,
  isDisabled = false,
  error,
  description,
  clearable = false,
}: ComboboxContract & { isDisabled?: boolean }) {
  validateChoices(options, value);
  const [query, setQuery] = useState(""),
    [open, setOpen] = useState(false);
  const selected = options.find((option) => option.value === value);
  const filtered = options.filter((option) =>
    option.label.toLocaleLowerCase().includes(query.toLocaleLowerCase()),
  );
  return (
    <HeroTextField isDisabled={isDisabled} isInvalid={!!error}>
      <Label>{label}</Label>
      <Select
        presentation="dialog"
        value={selected}
        onValueChange={(option) => onValueChange(option?.value)}
        isDisabled={isDisabled}
        onOpenChange={(open) => {
          setOpen(open);
          if (!open) setQuery("");
        }}
      >
        <Select.Trigger
          accessibilityRole="button"
          accessibilityLabel={label}
          accessibilityValue={{ text: selected?.label ?? "선택하지 않음" }}
          accessibilityState={{ expanded: open, disabled: isDisabled }}
          accessibilityHint={
            [error, description].filter(Boolean).join(". ") || undefined
          }
        >
          <Select.Value placeholder="선택해 주세요" />
          <Select.TriggerIndicator />
        </Select.Trigger>
        <Select.Portal unstable_accessibilityContainerViewIsModal>
          <Select.Overlay />
          <Select.Content presentation="dialog">
            <Select.Close accessibilityLabel="선택창을 닫아요" />
            <Select.ListLabel>{label}</Select.ListLabel>
            <Stack>
              <TextField
                label={`${label} 검색`}
                value={query}
                onChangeText={setQuery}
                autoCorrect={false}
              />
              <ScrollView
                style={styles.options}
                keyboardShouldPersistTaps="handled"
              >
                {filtered.length ? (
                  filtered.map((option) => (
                    <Select.Item
                      key={option.value}
                      value={option.value}
                      label={option.label}
                      disabled={option.disabled}
                    >
                      <Select.ItemLabel />
                      <Select.ItemIndicator />
                    </Select.Item>
                  ))
                ) : (
                  <BrandText muted>검색 결과가 없어요.</BrandText>
                )}
              </ScrollView>
            </Stack>
          </Select.Content>
        </Select.Portal>
      </Select>
      {clearable && value !== undefined && (
        <Button
          variant="ghost"
          isDisabled={isDisabled}
          onPress={() => onValueChange(undefined)}
          startContent={<Icon icon={X} />}
        >
          선택을 해제해요
        </Button>
      )}
      {description && <Description>{description}</Description>}
      <FieldError accessibilityLiveRegion="polite">{error}</FieldError>
    </HeroTextField>
  );
}
function DatePickerView({
  label,
  value,
  onValueChange,
  min,
  max,
  isDisabled,
  error,
  description,
}: {
  label: string;
  value?: string;
  onValueChange: (value: string | undefined) => void;
  min?: string;
  max?: string;
  isDisabled?: boolean;
  error?: string;
  description?: string;
}) {
  const [open, setOpen] = useState(false),
    [draft, setDraft] = useState(() =>
      value ? parseLocalDate(value) : new Date(),
    );
  const { resolvedMode } = useTheme();
  if (min && max && min > max)
    throw new RangeError("최소 날짜가 최대 날짜보다 늦어요.");
  const minimumDate = min ? parseLocalDate(min) : undefined,
    maximumDate = max ? parseLocalDate(max) : undefined;
  function prepareDraft() {
    const initial = value ? parseLocalDate(value) : new Date();
    setDraft(initial);
    return initial;
  }
  function showAndroid() {
    if (open) return;
    const initial = prepareDraft();
    if (Platform.OS === "android") {
      setOpen(true);
      DateTimePickerAndroid.open({
        value: initial,
        mode: "date",
        minimumDate,
        maximumDate,
        onValueChange: (_, date) => {
          if (!date) return;
          setOpen(false);
          onValueChange(toLocalDate(date));
        },
        onDismiss: () => setOpen(false),
      });
    }
  }
  const trigger = (
    <Button
      variant="outline"
      isDisabled={isDisabled}
      onPress={Platform.OS === "android" ? showAndroid : undefined}
      startContent={<Icon icon={CalendarDays} />}
      accessibilityLabel={label}
      accessibilityValue={{
        text: value ? displayDate(value) : "선택하지 않음",
      }}
      accessibilityState={{ expanded: open, disabled: isDisabled }}
      accessibilityHint="날짜 선택기를 열어요"
    >
      {value ? displayDate(value) : "날짜를 선택해 주세요"}
    </Button>
  );
  const iosDialog = (
    <Dialog
      isOpen={open}
      onOpenChange={(nextOpen) => {
        if (nextOpen) prepareDraft();
        setOpen(nextOpen);
      }}
    >
      <Dialog.Trigger asChild>{trigger}</Dialog.Trigger>
      <Dialog.Portal unstable_accessibilityContainerViewIsModal>
        {open && (
          <>
            <Dialog.Overlay />
            <Dialog.Content>
              <Dialog.Close accessibilityLabel="날짜 선택을 닫아요" />
              <Stack>
                <Dialog.Title>{label}</Dialog.Title>
                <Dialog.Description>
                  날짜를 고른 뒤 확인해 주세요.
                </Dialog.Description>
                <DateTimePicker
                  value={draft}
                  mode="date"
                  display="spinner"
                  locale="ko-KR"
                  themeVariant={resolvedMode}
                  minimumDate={minimumDate}
                  maximumDate={maximumDate}
                  onValueChange={(_, date) => {
                    if (date) setDraft(date);
                  }}
                  onDismiss={() => setOpen(false)}
                />
                <Stack direction="row">
                  <Button variant="outline" onPress={() => setOpen(false)}>
                    취소해요
                  </Button>
                  <Button
                    onPress={() => {
                      onValueChange(toLocalDate(draft));
                      setOpen(false);
                    }}
                  >
                    이 날짜로 정해요
                  </Button>
                </Stack>
              </Stack>
            </Dialog.Content>
          </>
        )}
      </Dialog.Portal>
    </Dialog>
  );
  return (
    <HeroTextField isDisabled={isDisabled} isInvalid={!!error}>
      <Label>{label}</Label>
      {Platform.OS === "ios" ? iosDialog : trigger}
      {description && <Description>{description}</Description>}
      <FieldError accessibilityLiveRegion="polite">{error}</FieldError>
    </HeroTextField>
  );
}
export function OTPField({
  label,
  value,
  onValueChange,
  length = 6,
  isDisabled,
  error,
  description,
}: {
  label: string;
  value: string;
  onValueChange: (value: string) => void;
  length?: 4 | 6;
  isDisabled?: boolean;
  error?: string;
  description?: string;
}) {
  return (
    <HeroTextField isDisabled={isDisabled} isInvalid={!!error}>
      <Label>{label}</Label>
      <InputOTP
        value={value}
        onChange={onValueChange}
        maxLength={length}
        inputMode="numeric"
        pattern="^\\d+$"
        isDisabled={isDisabled}
        isInvalid={!!error}
        textInputProps={{
          accessibilityLabel: label,
          textContentType: "oneTimeCode",
          autoComplete: "one-time-code",
        }}
      >
        <InputOTP.Group>
          {Array.from({ length }, (_, index) => (
            <InputOTP.Slot key={index} index={index} />
          ))}
        </InputOTP.Group>
      </InputOTP>
      {description && <Description>{description}</Description>}
      <FieldError accessibilityLiveRegion="polite">{error}</FieldError>
    </HeroTextField>
  );
}
export function RangeField({
  label,
  value,
  onValueChange,
  min = 0,
  max = 100,
  step = 1,
  unit = "",
  isDisabled,
}: {
  label: string;
  value: number;
  onValueChange: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  isDisabled?: boolean;
}) {
  if (
    !Number.isFinite(value) ||
    !Number.isFinite(min) ||
    !Number.isFinite(max) ||
    !Number.isFinite(step) ||
    max <= min ||
    step <= 0 ||
    value < min ||
    value > max
  )
    throw new RangeError("범위 값은 최소·최대 사이의 유효한 수여야 해요.");
  const [trackWidth, setTrackWidth] = useState(0),
    [thumbWidth, setThumbWidth] = useState(0);
  const sliderPercentage = Math.round(((value - min) / (max - min)) * 100),
    sliderAccessibilityValue = {
      min: 0,
      max: 100,
      now: Math.min(100, Math.max(0, sliderPercentage)),
      text: `${value}${unit}`,
    },
    thumbOffset =
      trackWidth > 0 && thumbWidth > 0
        ? ((trackWidth - thumbWidth) * (value - min)) / (max - min)
        : undefined;
  return (
    <Stack gap="sm">
      <View style={styles.row}>
        <BrandText variant="label">{label}</BrandText>
        <BrandText>
          {value}
          {unit}
        </BrandText>
      </View>
      <Slider
        value={value}
        onChange={(next) =>
          onValueChange(typeof next === "number" ? next : next[0]!)
        }
        minValue={min}
        maxValue={max}
        step={step}
        isDisabled={isDisabled}
        accessibilityLabel={label}
        accessibilityHint="값을 조절해요"
      >
        <Slider.Track
          onLayout={(event) => setTrackWidth(event.nativeEvent.layout.width)}
        >
          <Slider.TrackBackground />
          <Slider.Fill />
          <Slider.Thumb
            accessible
            accessibilityRole="adjustable"
            accessibilityLabel={label}
            accessibilityValue={sliderAccessibilityValue}
            accessibilityHint="값을 조절해요"
            onLayout={(event) => setThumbWidth(event.nativeEvent.layout.width)}
            style={
              thumbOffset === undefined ? undefined : { start: thumbOffset }
            }
          />
        </Slider.Track>
      </Slider>
    </Stack>
  );
}

const styles = StyleSheet.create({
  options: { maxHeight: metrics.size.control * 6 },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: metrics.space.sm,
  },
});

export const Combobox = withBrandErrorBoundary(
  ComboboxView,
  "선택 항목을 표시할 수 없어요",
);
export const DatePicker = withBrandErrorBoundary(
  DatePickerView,
  "날짜 선택을 표시할 수 없어요",
);
