import { type ComponentProps, type ReactNode } from "react";
import { StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { BottomSheet as HeroBottomSheet } from "heroui-native/bottom-sheet";
import { metrics } from "../generated/tokens";
import { BrandText } from "./components";
import { useReducedMotionSetting, useTheme } from "./provider";

type PortalProps = ComponentProps<typeof HeroBottomSheet.Portal>;
type ContentProps = ComponentProps<typeof HeroBottomSheet.Content>;

// @gorhom/bottom-sheet은 선택 peer라서 없으면 화면이 조용히 다른 모습이 돼요.
// 다른 UI로 대체하지 않고 설치해야 할 것을 분명히 알려요.
function assertNativePeer() {
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    require("@gorhom/bottom-sheet");
  } catch {
    throw new Error(
      "BottomSheet에는 @gorhom/bottom-sheet이 필요해요. " +
        "`npx expo install @gorhom/bottom-sheet`으로 설치한 뒤 다시 빌드해 주세요.",
    );
  }
}

const Portal = ({
  unstable_accessibilityContainerViewIsModal = true,
  ...props
}: PortalProps) => (
  <HeroBottomSheet.Portal
    unstable_accessibilityContainerViewIsModal={
      unstable_accessibilityContainerViewIsModal
    }
    {...props}
  />
);
Portal.displayName = "PixelLogicBottomSheetPortal";

export interface BottomSheetContentProps extends ContentProps {
  /** 시트 전체가 하나의 모달로 읽히도록 이름을 줘요. */
  accessibilityLabel?: string;
  /** 닫기 버튼의 접근성 이름이에요. */
  closeLabel?: string;
  /** false로 주면 아래로 끌어 닫기를 끕니다. */
  enablePanDownToClose?: boolean;
  children?: ReactNode;
}

const Content = ({
  accessibilityLabel,
  closeLabel = "시트를 닫아요",
  enablePanDownToClose = true,
  style,
  children,
  ...props
}: BottomSheetContentProps) => {
  assertNativePeer();
  const { colors } = useTheme();
  const reducedMotion = useReducedMotionSetting();
  const insets = useSafeAreaInsets();
  return (
    <HeroBottomSheet.Content
      accessible={false}
      accessibilityViewIsModal
      accessibilityLabel={accessibilityLabel}
      enablePanDownToClose={enablePanDownToClose}
      // 키보드가 올라와도 입력이 가려지지 않아야 해요.
      keyboardBehavior="interactive"
      keyboardBlurBehavior="restore"
      android_keyboardInputMode="adjustResize"
      animationConfigs={
        reducedMotion ? { duration: 0, dampingRatio: 1 } : undefined
      }
      style={[
        styles.content,
        {
          backgroundColor: colors.surface,
          borderColor: colors.border,
          paddingBottom: insets.bottom + metrics.space.page,
        },
        style,
      ]}
      {...props}
    >
      <HeroBottomSheet.Close accessibilityLabel={closeLabel} />
      {children}
    </HeroBottomSheet.Content>
  );
};
Content.displayName = "PixelLogicBottomSheetContent";

/** 아래로 끌어 닫을 수 있다는 걸 보여 주는 손잡이예요. 낭독 대상은 아니에요. */
const Handle = () => {
  const { colors } = useTheme();
  return (
    <View
      style={styles.handleArea}
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
    >
      <View style={[styles.handle, { backgroundColor: colors.border }]} />
    </View>
  );
};
Handle.displayName = "PixelLogicBottomSheetHandle";

const Header = ({ children }: { children: ReactNode }) => (
  <View style={styles.header}>{children}</View>
);
Header.displayName = "PixelLogicBottomSheetHeader";

const Title = ({ children }: { children: ReactNode }) => (
  <BrandText variant="heading" accessibilityRole="header">
    {children}
  </BrandText>
);
Title.displayName = "PixelLogicBottomSheetTitle";

const Description = ({ children }: { children: ReactNode }) => (
  <BrandText variant="label" muted>
    {children}
  </BrandText>
);
Description.displayName = "PixelLogicBottomSheetDescription";

export const BottomSheet = Object.assign(HeroBottomSheet, {
  Root: HeroBottomSheet,
  Portal,
  Content,
  Handle,
  Header,
  Title,
  Description,
});

const styles = StyleSheet.create({
  content: {
    borderTopLeftRadius: metrics.radius.dialog,
    borderTopRightRadius: metrics.radius.dialog,
    borderWidth: 1,
    borderBottomWidth: 0,
    paddingHorizontal: metrics.space.page,
    gap: metrics.space.lg,
  },
  handleArea: {
    alignItems: "center",
    paddingTop: metrics.space.sm,
    paddingBottom: metrics.space.xs,
  },
  handle: {
    width: metrics.size.control,
    height: metrics.space.xs,
    borderRadius: metrics.radius.pill,
  },
  header: { gap: metrics.space.xs },
});
