import { createContext, useContext, type ReactNode } from "react";
import { Pressable, ScrollView, StyleSheet, View } from "react-native";
import {
  PressableFeedback,
  type PressableFeedbackProps,
} from "heroui-native/pressable-feedback";
import { metrics } from "../generated/tokens";
import { BrandText } from "./components";
import { useTheme } from "./provider";

// 카드가 몇 열로 눕는지는 격자가 정하고 카드는 따르기만 해요.
const ColumnsContext = createContext<2 | 3 | null>(null);

const pressAnimation = {
  scale: { timingConfig: { duration: metrics.duration.fast } },
} satisfies NonNullable<PressableFeedbackProps["animation"]>;

export interface ChoiceGridProps {
  accessibilityLabel: string;
  children: ReactNode;
  /** 2열·3열 격자를 쓰거나, scroll을 켜면 한 줄 가로 스크롤이 돼요. */
  columns?: 2 | 3;
  scroll?: boolean;
}

/**
 * 선택 카드를 담는 radiogroup이에요. 스티커·색상·아이콘처럼
 * "여럿 중 하나"를 고르는 영역이 화면마다 다르게 조립되지 않도록 소유해요.
 */
export function ChoiceGrid({
  accessibilityLabel,
  children,
  columns = 3,
  scroll = false,
}: ChoiceGridProps) {
  if (scroll)
    return (
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        accessibilityRole="radiogroup"
        accessibilityLabel={accessibilityLabel}
        contentContainerStyle={styles.scrollRow}
        keyboardShouldPersistTaps="handled"
      >
        {children}
      </ScrollView>
    );
  return (
    <ColumnsContext.Provider value={columns}>
      <View
        accessibilityRole="radiogroup"
        accessibilityLabel={accessibilityLabel}
        style={styles.grid}
      >
        {children}
      </View>
    </ColumnsContext.Provider>
  );
}

export interface SelectableCardProps {
  value: string;
  label: string;
  selected: boolean;
  onPress: () => void;
  media?: ReactNode;
  description?: string;
  isDisabled?: boolean;
}

export function SelectableCard({
  value,
  label,
  selected,
  onPress,
  media,
  description,
  isDisabled = false,
}: SelectableCardProps) {
  const { colors } = useTheme();
  const columns = useContext(ColumnsContext);
  return (
    <PressableFeedback
      asChild
      isDisabled={isDisabled}
      animation={pressAnimation}
    >
      <Pressable
        onPress={isDisabled ? undefined : onPress}
        disabled={isDisabled}
        accessibilityRole="radio"
        // media와 label이 하나의 이름으로 읽히도록 카드가 이름을 소유해요.
        accessibilityLabel={[label, description].filter(Boolean).join(", ")}
        accessibilityState={{ selected, disabled: isDisabled }}
        accessibilityValue={{ text: value }}
        style={[
          styles.card,
          // 가로 스크롤(격자 밖)에서는 고유 너비를 유지해요.
          columns === 3
            ? styles.basisThird
            : columns === 2
              ? styles.basisHalf
              : null,
          {
            backgroundColor: isDisabled
              ? colors.disabled
              : selected
                ? colors.secondary
                : colors.surface,
            borderColor: selected ? colors.progress : colors.border,
          },
        ]}
      >
        {media && (
          <View
            style={styles.media}
            accessibilityElementsHidden
            importantForAccessibility="no-hide-descendants"
          >
            {media}
          </View>
        )}
        <BrandText
          variant="label"
          numberOfLines={1}
          style={isDisabled ? { color: colors.disabledForeground } : undefined}
        >
          {label}
        </BrandText>
        {description && (
          <BrandText variant="caption" muted numberOfLines={1}>
            {description}
          </BrandText>
        )}
      </Pressable>
    </PressableFeedback>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: "row", flexWrap: "wrap", gap: metrics.space.md },
  basisHalf: { flexBasis: "47%" },
  basisThird: { flexBasis: "30%" },
  scrollRow: { flexDirection: "row", gap: metrics.space.md },
  card: {
    flexGrow: 1,
    minWidth: metrics.size.mascotSmall,
    minHeight: metrics.size.control,
    alignItems: "center",
    justifyContent: "center",
    gap: metrics.space.xs,
    padding: metrics.space.md,
    borderWidth: 1,
    borderRadius: metrics.radius.card,
  },
  media: { alignItems: "center", justifyContent: "center" },
});
