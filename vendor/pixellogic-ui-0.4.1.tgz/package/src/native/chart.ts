// react-native-svg를 쓰는 유일한 진입점이에요.
export * from "./trend-chart";
export type { ChartPoint, ChartKind } from "../shared/chart";
export type { TrendChartContract } from "../shared/contracts";
