import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type LayoutChangeEvent,
} from "react-native";
import {
  PressableFeedback,
  type PressableFeedbackProps,
} from "heroui-native/pressable-feedback";
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Search,
  type LucideIcon,
} from "lucide-react-native";
import { metrics, nativeFontFamily } from "../generated/tokens";
import type { SemanticTone } from "../shared/brand";
import { BrandText, Button, Icon, IconButton } from "./components";
import { useReducedMotionSetting, useTheme } from "./provider";

const calendarPressAnimation = {
  scale: { timingConfig: { duration: metrics.duration.fast } },
} satisfies NonNullable<PressableFeedbackProps["animation"]>;

export type CalendarGridDay = { key: string; date: Date; inMonth: boolean };
export type CalendarNavItem = { key: string; label: string; icon: LucideIcon };
export type CalendarDayEvent = {
  key: string;
  label: string;
  tone?: SemanticTone;
};
/** 날짜 칸이 개수를 읽어 주는 문구예요. 일정 화면과 할 일 화면이 같은 grid를 쓰되
 *  서로 다른 명사로 읽히도록 호출부가 소유해요. */
export type CalendarCountLabel = (
  count: number,
  day: CalendarGridDay,
) => string;

export function CalendarMonthPager({
  month,
  onMonthChange,
  renderMonth,
}: {
  month: Date;
  onMonthChange: (month: Date) => void;
  renderMonth: (month: Date) => ReactNode;
}) {
  const [width, setWidth] = useState(0);
  const reducedMotion = useReducedMotionSetting();
  const scroll = useRef<ScrollView>(null),
    hasCentered = useRef(false),
    recenterImmediately = useRef(false);
  const pages = [
    new Date(month.getFullYear(), month.getMonth() - 1, 1),
    month,
    new Date(month.getFullYear(), month.getMonth() + 1, 1),
  ];
  function layout(event: LayoutChangeEvent) {
    setWidth(event.nativeEvent.layout.width);
  }
  useEffect(() => {
    if (!width) return;
    scroll.current?.scrollTo({
      x: width,
      animated:
        hasCentered.current && !recenterImmediately.current && !reducedMotion,
    });
    hasCentered.current = true;
    recenterImmediately.current = false;
  }, [month, reducedMotion, width]);
  return (
    <View style={styles.pager} onLayout={layout}>
      <ScrollView
        ref={scroll}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        contentOffset={{ x: width, y: 0 }}
        onMomentumScrollEnd={(event) => {
          if (!width) return;
          const index = Math.round(event.nativeEvent.contentOffset.x / width);
          if (index === 1) return;
          recenterImmediately.current = true;
          onMonthChange(
            new Date(
              month.getFullYear(),
              month.getMonth() + (index === 0 ? -1 : 1),
              1,
            ),
          );
        }}
      >
        {pages.map((page, index) => (
          <View
            key={`${page.getFullYear()}-${page.getMonth()}`}
            style={{ width }}
            accessible={false}
            accessibilityElementsHidden={index !== 1}
            importantForAccessibility={
              index === 1 ? "yes" : "no-hide-descendants"
            }
          >
            {renderMonth(page)}
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

export function CalendarToolbar({
  month,
  onPrevious,
  onNext,
  onToday,
  onSearch,
}: {
  month: Date;
  onPrevious: () => void;
  onNext: () => void;
  onToday: () => void;
  onSearch?: () => void;
}) {
  return (
    <View style={styles.toolbar}>
      <BrandText
        variant="heading"
        accessibilityRole="header"
        numberOfLines={1}
        ellipsizeMode="clip"
        style={styles.monthLabel}
      >
        {month.getFullYear()}년 {month.getMonth() + 1}월
      </BrandText>
      <View style={styles.toolbarActions}>
        <Button variant="ghost" onPress={onToday}>
          오늘
        </Button>
        {onSearch && (
          <IconButton
            icon={Search}
            label="일정 검색"
            variant="ghost"
            onPress={onSearch}
          />
        )}
        <IconButton
          icon={ChevronLeft}
          label="이전 달"
          variant="ghost"
          onPress={onPrevious}
        />
        <IconButton
          icon={ChevronRight}
          label="다음 달"
          variant="ghost"
          onPress={onNext}
        />
      </View>
    </View>
  );
}

export function CalendarMonthGrid({
  days,
  weekdays,
  selectedKey,
  todayKey,
  eventsByDate,
  eventCountLabel = (count) => `일정 ${count}개`,
  onDatePress,
  onOutsideMonthPress,
  renderDayAccessory,
  renderDayMeta,
}: {
  days: readonly CalendarGridDay[];
  weekdays: readonly string[];
  selectedKey: string;
  todayKey: string;
  eventsByDate?: Readonly<Record<string, number>>;
  /** 기본값은 일정 화면과 호환되는 "일정 n개"예요. */
  eventCountLabel?: CalendarCountLabel;
  onDatePress: (day: CalendarGridDay) => void;
  /** 인접 월 날짜를 누르면 해당 월로 이동시키는 명시적 경로예요. */
  onOutsideMonthPress?: (day: CalendarGridDay) => void;
  renderDayAccessory?: (day: CalendarGridDay) => ReactNode;
  renderDayMeta?: (day: CalendarGridDay, eventCount: number) => ReactNode;
}) {
  const { colors } = useTheme();
  const rows = useMemo(
    () =>
      Array.from({ length: Math.ceil(days.length / 7) }, (_, index) =>
        days.slice(index * 7, index * 7 + 7),
      ),
    [days],
  );
  return (
    <View style={styles.grid} accessible={false}>
      <View style={[styles.weekdayRow, { borderColor: colors.border }]}>
        {weekdays.map((label, index) => (
          <Text
            key={`${label}-${index}`}
            style={[
              styles.weekday,
              {
                color:
                  index === 0
                    ? colors.danger
                    : index === 6
                      ? colors.info
                      : colors.mutedForeground,
              },
            ]}
          >
            {label}
          </Text>
        ))}
      </View>
      {rows.map((row, rowIndex) => (
        <View key={rowIndex} style={styles.row}>
          {row.map((day) => (
            <CalendarDayCell
              key={day.key}
              day={day}
              selected={day.key === selectedKey}
              today={day.key === todayKey}
              eventCount={eventsByDate?.[day.key] ?? 0}
              eventCountLabel={eventCountLabel}
              onPress={() =>
                day.inMonth ? onDatePress(day) : onOutsideMonthPress?.(day)
              }
              outsideMonth={!day.inMonth}
              canOpenOutsideMonth={!!onOutsideMonthPress}
              accessory={renderDayAccessory?.(day)}
              dayMeta={renderDayMeta?.(day, eventsByDate?.[day.key] ?? 0)}
            />
          ))}
        </View>
      ))}
    </View>
  );
}

function CalendarDayCell({
  day,
  selected,
  today,
  eventCount,
  eventCountLabel,
  onPress,
  outsideMonth,
  canOpenOutsideMonth,
  accessory,
  dayMeta,
}: {
  day: CalendarGridDay;
  selected: boolean;
  today: boolean;
  eventCount: number;
  eventCountLabel: CalendarCountLabel;
  onPress: () => void;
  outsideMonth: boolean;
  canOpenOutsideMonth: boolean;
  accessory?: ReactNode;
  dayMeta?: ReactNode;
}) {
  const { colors } = useTheme();
  const disabled = outsideMonth && !canOpenOutsideMonth;
  return (
    <PressableFeedback
      asChild
      isDisabled={disabled}
      animation={calendarPressAnimation}
    >
      <Pressable
        onPress={disabled ? undefined : onPress}
        disabled={disabled}
        accessibilityRole="button"
        accessibilityLabel={[
          `${day.date.getMonth() + 1}월 ${day.date.getDate()}일`,
          today ? "오늘" : "",
          outsideMonth ? "이번 달이 아니에요" : "",
          eventCount ? eventCountLabel(eventCount, day) : "",
        ]
          .filter(Boolean)
          .join(", ")}
        accessibilityState={{ selected, disabled }}
        accessibilityHint={
          outsideMonth && canOpenOutsideMonth ? "해당 월로 이동해요" : undefined
        }
        style={[styles.dayCell, { borderColor: colors.border }]}
      >
        <View
          style={[
            styles.dayCircle,
            today && { borderColor: colors.progress },
            selected && {
              backgroundColor: colors.secondary,
              borderColor: colors.progress,
            },
          ]}
        >
          <Text
            style={[
              styles.dayNumber,
              {
                // 누를 수 없는 인접 월 날짜는 색으로도 구분돼야 해요.
                color: disabled
                  ? colors.disabledForeground
                  : day.inMonth
                    ? colors.foreground
                    : colors.mutedForeground,
              },
              today && {
                color: colors.progress,
                fontWeight: metrics.fontWeight.bold,
              },
            ]}
          >
            {day.date.getDate()}
          </Text>
        </View>
        <View style={styles.dayMeta}>
          {dayMeta ??
            (eventCount > 0 && (
              <Text style={[styles.eventCount, { color: colors.progress }]}>
                {eventCount}
              </Text>
            ))}
          {accessory}
        </View>
      </Pressable>
    </PressableFeedback>
  );
}

/**
 * 날짜 칸 아래에 들어가는 메타 조합이에요. `CalendarMonthGrid`의 `renderDayMeta`에
 * 넘겨 쓰고, 일정 pill·공휴일·스티커가 화면마다 다르게 그려지지 않도록 소유해요.
 *
 * 낭독은 날짜 칸이 `eventCountLabel`로 이미 담당하므로 여기서 중복해 읽지 않아요.
 */
export function CalendarDayMeta({
  events = [],
  holiday,
  sticker,
  maxVisible = 2,
}: {
  events?: readonly CalendarDayEvent[];
  holiday?: string;
  sticker?: ReactNode;
  /** 넘치는 개수는 +n으로 접어요. */
  maxVisible?: number;
}) {
  const { colors } = useTheme();
  const visible = events.slice(0, Math.max(0, maxVisible));
  const toneColors = (tone: SemanticTone | undefined) =>
    !tone || tone === "neutral"
      ? { background: colors.secondary, foreground: colors.secondaryForeground }
      : { background: colors[`${tone}Soft`], foreground: colors[tone] };
  const overflow = events.length - visible.length;
  return (
    <View
      style={styles.meta}
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
    >
      {holiday && (
        <Text
          numberOfLines={1}
          style={[styles.holiday, { color: colors.danger }]}
        >
          {holiday}
        </Text>
      )}
      {visible.map((event) => (
        <View
          key={event.key}
          style={[
            styles.pill,
            { backgroundColor: toneColors(event.tone).background },
          ]}
        >
          <Text
            numberOfLines={1}
            style={[
              styles.pillLabel,
              { color: toneColors(event.tone).foreground },
            ]}
          >
            {event.label}
          </Text>
        </View>
      ))}
      {overflow > 0 && (
        <Text style={[styles.overflow, { color: colors.mutedForeground }]}>
          +{overflow}
        </Text>
      )}
      {sticker}
    </View>
  );
}

export function CalendarBottomNav({
  items,
  value,
  onChange,
}: {
  items: readonly CalendarNavItem[];
  value: string;
  onChange: (key: string) => void;
}) {
  const { colors } = useTheme();
  return (
    <View
      style={[
        styles.bottomNav,
        { backgroundColor: colors.background, borderColor: colors.border },
      ]}
      accessibilityRole="tablist"
      accessibilityLabel="달력 내비게이션"
    >
      {items.map((item) => (
        <PressableFeedback
          key={item.key}
          asChild
          animation={calendarPressAnimation}
        >
          <Pressable
            onPress={() => onChange(item.key)}
            accessibilityRole="tab"
            accessibilityLabel={item.label}
            accessibilityState={{ selected: value === item.key }}
            style={styles.navItem}
          >
            <Icon
              icon={item.icon}
              color={
                value === item.key ? colors.progress : colors.mutedForeground
              }
            />
            <BrandText
              variant="caption"
              style={{
                color:
                  value === item.key ? colors.progress : colors.mutedForeground,
              }}
            >
              {item.label}
            </BrandText>
          </Pressable>
        </PressableFeedback>
      ))}
    </View>
  );
}

export function CalendarAddButton({ onPress }: { onPress: () => void }) {
  return (
    <IconButton
      icon={Plus}
      label="일정 추가"
      onPress={onPress}
      style={styles.addButton}
    />
  );
}

const styles = StyleSheet.create({
  toolbar: {
    minHeight: metrics.space.hero,
    gap: metrics.space.sm,
    paddingHorizontal: metrics.space.lg,
    paddingVertical: metrics.space.sm,
  },
  monthLabel: { flexShrink: 0 },
  toolbarActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: metrics.space.xs,
    alignSelf: "flex-end",
  },
  pager: { flex: 1 },
  grid: { flex: 1 },
  weekdayRow: {
    flexDirection: "row",
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  weekday: {
    flex: 1,
    textAlign: "center",
    fontFamily: nativeFontFamily,
    fontSize: metrics.fontSize.label,
    fontWeight: metrics.fontWeight.semibold,
    paddingVertical: metrics.space.md,
  },
  row: { flex: 1, flexDirection: "row" },
  dayCell: {
    flex: 1,
    minHeight: metrics.size.calendarDay * 2 + metrics.space.sm,
    alignItems: "center",
    paddingTop: metrics.space.sm,
    borderRightWidth: StyleSheet.hairlineWidth,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  dayCircle: {
    width: metrics.size.calendarDay,
    height: metrics.size.calendarDay,
    borderRadius: metrics.size.calendarDay / 2,
    borderWidth: metrics.stroke,
    borderColor: "transparent",
    alignItems: "center",
    justifyContent: "center",
  },
  dayNumber: { fontFamily: nativeFontFamily, fontSize: metrics.fontSize.body },
  dayMeta: {
    minHeight: metrics.fontSize.label * metrics.lineHeight.normal,
    alignItems: "center",
    justifyContent: "center",
  },
  eventCount: {
    fontFamily: nativeFontFamily,
    fontSize: metrics.fontSize.caption,
    fontWeight: metrics.fontWeight.bold,
  },
  meta: { alignItems: "center", gap: metrics.space.xs, width: "100%" },
  holiday: {
    fontFamily: nativeFontFamily,
    fontSize: metrics.fontSize.caption,
    fontWeight: metrics.fontWeight.semibold,
  },
  pill: {
    maxWidth: "100%",
    borderRadius: metrics.radius.pill,
    paddingHorizontal: metrics.space.xs,
  },
  pillLabel: {
    fontFamily: nativeFontFamily,
    fontSize: metrics.fontSize.caption,
  },
  overflow: {
    fontFamily: nativeFontFamily,
    fontSize: metrics.fontSize.caption,
    fontWeight: metrics.fontWeight.semibold,
  },
  bottomNav: {
    flexDirection: "row",
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingTop: metrics.space.sm,
    paddingBottom: metrics.space.sm,
  },
  navItem: {
    flex: 1,
    alignItems: "center",
    gap: metrics.space.xs,
    minHeight: metrics.size.row,
    justifyContent: "center",
  },
  addButton: {
    alignSelf: "flex-end",
    marginRight: metrics.space.lg,
    width: metrics.size.row,
    minWidth: metrics.size.row,
    height: metrics.size.row,
    minHeight: metrics.size.row,
    borderRadius: metrics.size.row / 2,
    paddingHorizontal: 0,
  },
});
