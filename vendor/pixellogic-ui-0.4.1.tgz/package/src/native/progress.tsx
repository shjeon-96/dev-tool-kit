import { useEffect, type ReactNode } from "react";
import { StyleSheet, View } from "react-native";
import Svg, { Circle } from "react-native-svg";
import Animated, {
  FadeIn,
  ReduceMotion,
  interpolateColor,
  useAnimatedProps,
  useSharedValue,
  withTiming,
} from "react-native-reanimated";
import { metrics } from "../generated/tokens";
import {
  goalProgress,
  formatMetric,
  goalValueText,
  type GoalProps,
} from "../shared/progress";
import { BoriMascot, BrandText } from "./components";
import { useTheme } from "./provider";
import { withBrandErrorBoundary } from "./error-boundary";
const AnimatedCircle = Animated.createAnimatedComponent(Circle);
function MetricView({
  label,
  value,
  unit,
  detail,
  locale,
}: {
  label: string;
  value: number;
  unit: string;
  detail?: string;
  locale?: string;
}) {
  return (
    <View style={styles.metric}>
      <BrandText variant="heading">{label}</BrandText>
      <View style={styles.valueRow}>
        <BrandText variant="metric" style={styles.bold}>
          {formatMetric(value, locale)}
        </BrandText>
        <BrandText variant="title">{unit}</BrandText>
      </View>
      {detail && (
        <BrandText variant="label" muted>
          {detail}
        </BrandText>
      )}
    </View>
  );
}
function GoalProgressView({
  action,
  ...props
}: GoalProps & { action?: ReactNode }) {
  const goal = goalProgress(props),
    { colors } = useTheme();
  const size = metrics.size.progress,
    stroke = metrics.size.progressStroke;
  const radius = (size - stroke) / 2,
    circumference = 2 * Math.PI * radius;
  const fraction = useSharedValue(goal.fraction);
  const completion = useSharedValue(goal.complete ? 1 : 0);
  useEffect(() => {
    fraction.value = withTiming(goal.fraction, {
      duration: metrics.duration.normal,
      reduceMotion: ReduceMotion.System,
    });
  }, [fraction, goal.fraction]);
  useEffect(() => {
    completion.value = withTiming(goal.complete ? 1 : 0, {
      duration: metrics.duration.fast,
      reduceMotion: ReduceMotion.System,
    });
  }, [completion, goal.complete]);
  const animatedProps = useAnimatedProps(() => ({
    strokeDashoffset: circumference * (1 - fraction.value),
    stroke: interpolateColor(
      completion.value,
      [0, 1],
      [colors.progress, colors.success],
    ),
  }));
  return (
    <View style={styles.goal}>
      <View
        style={styles.visual}
        accessible
        accessibilityRole="progressbar"
        accessibilityLabel={props.label}
        accessibilityValue={{
          min: 0,
          max: 100,
          now: Math.round(goal.fraction * 100),
          text: `${goalValueText(props)}, ${goal.percentage}%`,
        }}
      >
        <Svg
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
          accessible={false}
        >
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={colors.secondary}
            strokeWidth={stroke}
          />
          {goal.fraction > 0 && (
            <AnimatedCircle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="none"
              strokeWidth={stroke}
              strokeLinecap="round"
              strokeDasharray={circumference}
              animatedProps={animatedProps}
              rotation={-90}
              origin={`${size / 2}, ${size / 2}`}
            />
          )}
        </Svg>
        <View style={styles.percent} pointerEvents="none">
          <BrandText variant="metric" style={styles.bold}>
            {formatMetric(goal.percentage, props.locale)}
          </BrandText>
          <BrandText variant="heading">%</BrandText>
        </View>
      </View>
      <View style={styles.copy}>
        <BrandText variant="title">{goalValueText(props)}</BrandText>
        <BrandText>{props.label}</BrandText>
        <BrandText variant="label" muted>
          {goal.complete
            ? "목표를 채웠어요"
            : `${formatMetric(goal.remaining, props.locale)}${props.unit} 남았어요`}
        </BrandText>
      </View>
      {action}
    </View>
  );
}
function MilestoneView({
  title = "목표를 채웠어요",
  ...props
}: GoalProps & { title?: string }) {
  if (!goalProgress(props).complete) return null;
  return (
    <Animated.View
      style={styles.milestone}
      entering={FadeIn.duration(metrics.duration.fast).reduceMotion(
        ReduceMotion.System,
      )}
      accessible
      accessibilityRole="text"
      accessibilityLabel={`${props.label}. ${title}. ${goalValueText(props)}. 달성했어요`}
      accessibilityLiveRegion="polite"
    >
      <BoriMascot asset="success" size="medium" />
      <View style={styles.milestoneCopy}>
        <BrandText variant="label" muted>
          {props.label}
        </BrandText>
        <BrandText variant="heading">{title}</BrandText>
        <BrandText>{goalValueText(props)}</BrandText>
      </View>
    </Animated.View>
  );
}
const styles = StyleSheet.create({
  metric: { gap: metrics.space.sm },
  valueRow: {
    flexDirection: "row",
    alignItems: "baseline",
    gap: metrics.space.sm,
  },
  bold: {
    fontWeight: metrics.fontWeight.bold,
    fontVariant: ["tabular-nums"],
  },
  goal: { alignItems: "center", gap: metrics.space.lg },
  visual: { width: metrics.size.progress, height: metrics.size.progress },
  percent: {
    ...StyleSheet.absoluteFill,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  copy: { alignItems: "center", gap: metrics.space.xs },
  milestone: {
    flexDirection: "row",
    alignItems: "center",
    gap: metrics.space.lg,
  },
  milestoneCopy: { flex: 1, gap: metrics.space.sm },
});

export const Metric = withBrandErrorBoundary(
  MetricView,
  "지표를 표시할 수 없어요",
);
export const GoalProgress = withBrandErrorBoundary(
  GoalProgressView,
  "진행률을 표시할 수 없어요",
);
export const Milestone = withBrandErrorBoundary(
  MilestoneView,
  "달성 정보를 표시할 수 없어요",
);
