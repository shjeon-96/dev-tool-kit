import { forwardRef, type ComponentProps, type ComponentRef } from "react";
import { InputOTP as HeroInputOTP } from "heroui-native/input-otp";
import {
  FadeIn,
  FadeOut,
  FlipInXDown,
  FlipOutXDown,
  ReduceMotion,
} from "react-native-reanimated";
import { metrics } from "../generated/tokens";

type InputOTPSlotValueProps = ComponentProps<typeof HeroInputOTP.SlotValue>;
type InputOTPSlotCaretProps = ComponentProps<typeof HeroInputOTP.SlotCaret>;

const slotValueAnimation = {
  wrapper: {
    entering: FadeIn.duration(metrics.duration.fast).reduceMotion(
      ReduceMotion.System,
    ),
    exiting: FadeOut.duration(metrics.duration.fast).reduceMotion(
      ReduceMotion.System,
    ),
  },
  text: {
    entering: FlipInXDown.duration(metrics.duration.fast).reduceMotion(
      ReduceMotion.System,
    ),
    exiting: FlipOutXDown.duration(metrics.duration.fast).reduceMotion(
      ReduceMotion.System,
    ),
  },
} satisfies NonNullable<InputOTPSlotValueProps["animation"]>;

const slotCaretAnimation = {
  opacity: { duration: metrics.duration.fast },
  height: { duration: metrics.duration.fast },
} satisfies NonNullable<InputOTPSlotCaretProps["animation"]>;

const SlotValue = forwardRef<
  ComponentRef<typeof HeroInputOTP.SlotValue>,
  InputOTPSlotValueProps
>(({ animation = slotValueAnimation, ...props }, ref) => (
  <HeroInputOTP.SlotValue ref={ref} animation={animation} {...props} />
));

SlotValue.displayName = "PixelLogicInputOTPSlotValue";

const SlotCaret = forwardRef<
  ComponentRef<typeof HeroInputOTP.SlotCaret>,
  InputOTPSlotCaretProps
>(({ animation = slotCaretAnimation, ...props }, ref) => (
  <HeroInputOTP.SlotCaret ref={ref} animation={animation} {...props} />
));

SlotCaret.displayName = "PixelLogicInputOTPSlotCaret";

export const InputOTP = Object.assign(HeroInputOTP, { SlotValue, SlotCaret });
