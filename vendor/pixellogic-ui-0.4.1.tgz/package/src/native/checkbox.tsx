import { forwardRef, type ComponentProps, type ComponentRef } from "react";
import { Checkbox as HeroCheckbox } from "heroui-native/checkbox";
import { metrics } from "../generated/tokens";

type CheckboxProps = ComponentProps<typeof HeroCheckbox>;
type CheckboxIndicatorProps = ComponentProps<typeof HeroCheckbox.Indicator>;

const rootAnimation = {
  scale: { timingConfig: { duration: metrics.duration.fast } },
} satisfies NonNullable<CheckboxProps["animation"]>;

const indicatorAnimation = {
  opacity: { timingConfig: { duration: metrics.duration.fast } },
  borderRadius: { timingConfig: { duration: metrics.duration.fast } },
  translateX: { timingConfig: { duration: metrics.duration.fast } },
  scale: { timingConfig: { duration: metrics.duration.fast } },
} satisfies NonNullable<CheckboxIndicatorProps["animation"]>;

const Root = forwardRef<ComponentRef<typeof HeroCheckbox>, CheckboxProps>(
  ({ animation = rootAnimation, ...props }, ref) => (
    <HeroCheckbox ref={ref} animation={animation} {...props} />
  ),
);

Root.displayName = "PixelLogicCheckbox";

const Indicator = forwardRef<
  ComponentRef<typeof HeroCheckbox.Indicator>,
  CheckboxIndicatorProps
>(({ animation = indicatorAnimation, ...props }, ref) => (
  <HeroCheckbox.Indicator ref={ref} animation={animation} {...props} />
));

Indicator.displayName = "PixelLogicCheckboxIndicator";

export const Checkbox = Object.assign(Root, {
  Indicator,
  Background: HeroCheckbox.Background,
});
