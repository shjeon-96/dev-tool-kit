import { useEffect } from "react";
import { StyleSheet, View } from "react-native";
import { Check } from "lucide-react-native";
import { metrics } from "../generated/tokens";
import type { StepperContract } from "../shared/contracts";
import { BrandText, Icon } from "./components";
import { withBrandErrorBoundary } from "./error-boundary";
import { useTheme } from "./provider";
import Animated, {
  interpolateColor,
  ReduceMotion,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
  type SharedValue,
} from "react-native-reanimated";

type ThemeColors = ReturnType<typeof useTheme>["colors"];

function StepItem({
  index,
  label,
  current,
  progress,
  colors,
}: {
  index: number;
  label: string;
  current: number;
  progress: SharedValue<number>;
  colors: ThemeColors;
}) {
  const animatedStyle = useAnimatedStyle(() => ({
    backgroundColor: interpolateColor(
      progress.value,
      [index - 1, index, index + 1],
      [colors.muted, colors.secondary, colors.successSoft],
    ),
  }));
  return (
    <Animated.View style={[styles.step, animatedStyle]}>
      {index < current ? (
        <Icon icon={Check} color={colors.success} />
      ) : (
        <BrandText variant="label">{index + 1}</BrandText>
      )}
      <BrandText variant="label">{label}</BrandText>
    </Animated.View>
  );
}

function StepperView({ steps, current }: StepperContract) {
  if (!Number.isInteger(current) || current < 0 || current >= steps.length)
    throw new RangeError("현재 단계가 단계 목록의 범위를 벗어났어요.");
  const { colors } = useTheme();
  const progress = useSharedValue(current);
  useEffect(() => {
    progress.value = withTiming(current, {
      duration: metrics.duration.normal,
      reduceMotion: ReduceMotion.System,
    });
  }, [current, progress]);
  return (
    <View
      style={styles.row}
      accessibilityRole="progressbar"
      role="progressbar"
      accessible
      accessibilityLabel="진행 단계"
      accessibilityValue={{
        min: 1,
        max: steps.length,
        now: current + 1,
        text: `${steps.length}단계 중 ${current + 1}단계, ${steps[current]}`,
      }}
      accessibilityLiveRegion="polite"
    >
      {steps.map((label, index) => (
        <StepItem
          key={`${index}-${label}`}
          index={index}
          label={label}
          current={current}
          progress={progress}
          colors={colors}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: metrics.space.sm,
  },
  step: {
    flexDirection: "row",
    alignItems: "center",
    gap: metrics.space.xs,
    padding: metrics.space.sm,
    borderRadius: metrics.radius.sm,
    flex: 1,
  },
});

export const Stepper = withBrandErrorBoundary(
  StepperView,
  "단계를 표시할 수 없어요",
);
