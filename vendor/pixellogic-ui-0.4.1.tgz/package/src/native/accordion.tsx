import { forwardRef, type ComponentProps, type ComponentRef } from "react";
import { Accordion as HeroAccordion } from "heroui-native/accordion";
import {
  FadeIn,
  FadeOut,
  LinearTransition,
  ReduceMotion,
} from "react-native-reanimated";
import { metrics } from "../generated/tokens";

type AccordionProps = ComponentProps<typeof HeroAccordion>;
type AccordionContentProps = ComponentProps<typeof HeroAccordion.Content>;

export const AccordionLayoutTransition = LinearTransition.duration(
  metrics.duration.normal,
).reduceMotion(ReduceMotion.System);

const rootAnimation = {
  layout: {
    value: AccordionLayoutTransition,
  },
} satisfies NonNullable<AccordionProps["animation"]>;

const contentAnimation = {
  entering: {
    value: FadeIn.duration(metrics.duration.normal).reduceMotion(
      ReduceMotion.System,
    ),
  },
  exiting: {
    value: FadeOut.duration(metrics.duration.fast).reduceMotion(
      ReduceMotion.System,
    ),
  },
} satisfies NonNullable<AccordionContentProps["animation"]>;

const Root = forwardRef<ComponentRef<typeof HeroAccordion>, AccordionProps>(
  ({ animation = rootAnimation, ...props }, ref) => (
    <HeroAccordion ref={ref} animation={animation} {...props} />
  ),
);

Root.displayName = "PixelLogicAccordion";

const Content = forwardRef<
  ComponentRef<typeof HeroAccordion.Content>,
  AccordionContentProps
>(({ animation = contentAnimation, ...props }, ref) => (
  <HeroAccordion.Content ref={ref} animation={animation} {...props} />
));

Content.displayName = "PixelLogicAccordionContent";

export const Accordion = Object.assign(Root, {
  Background: HeroAccordion.Background,
  Item: HeroAccordion.Item,
  Trigger: HeroAccordion.Trigger,
  Indicator: HeroAccordion.Indicator,
  Content,
});
