import type { ReactNode } from "react";
import { StyleSheet, View } from "react-native";
import { ControlField } from "heroui-native/control-field";
import { metrics } from "../generated/tokens";
import { Checkbox } from "./checkbox";
import { BrandText } from "./components";
import { useTheme } from "./provider";

export interface CheckboxRowProps {
  title: string;
  description?: string;
  isSelected: boolean;
  onSelectedChange: (selected: boolean) => void;
  isDisabled?: boolean;
  /** 저장이 끝나기 전에도 행을 유지하면서 진행 중임을 알려요. */
  isBusy?: boolean;
  /** 값이 규칙에 맞지 않을 때 색 말고 문구로도 알려요. */
  invalidMessage?: string;
  leading?: ReactNode;
  trailing?: ReactNode;
}

/**
 * 체크 상태를 가진 목록 행이에요. 행 전체와 체크박스 모두로 토글되고,
 * 완료를 색 하나로만 표현하지 않도록 체크 상태와 취소선을 함께 씁니다.
 */
export function CheckboxRow({
  title,
  description,
  isSelected,
  onSelectedChange,
  isDisabled = false,
  isBusy = false,
  invalidMessage,
  leading,
  trailing,
}: CheckboxRowProps) {
  const { colors } = useTheme();
  const locked = isDisabled || isBusy;
  return (
    <View>
      <ControlField
        isSelected={isSelected}
        onSelectedChange={onSelectedChange}
        isDisabled={locked}
        // 행 전체가 하나의 체크박스로 읽혀야 상태가 한 번에 전달돼요.
        accessibilityRole="checkbox"
        accessibilityLabel={`${title} 완료`}
        accessibilityHint={description}
        accessibilityState={{
          checked: isSelected,
          disabled: locked,
          busy: isBusy,
        }}
        style={styles.row}
      >
        <ControlField.Indicator>
          <Checkbox>
            <Checkbox.Indicator />
          </Checkbox>
        </ControlField.Indicator>
        {leading}
        <View style={styles.copy}>
          <BrandText
            style={
              isSelected
                ? {
                    textDecorationLine: "line-through",
                    color: colors.mutedForeground,
                  }
                : undefined
            }
          >
            {title}
          </BrandText>
          {description && (
            <BrandText variant="label" muted>
              {description}
            </BrandText>
          )}
        </View>
        {trailing}
      </ControlField>
      {invalidMessage && (
        <BrandText
          variant="label"
          style={[styles.invalid, { color: colors.danger }]}
          accessibilityLiveRegion="polite"
        >
          {invalidMessage}
        </BrandText>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    // 48pt 미만이면 손가락이 닿지 않아요.
    minHeight: metrics.size.control,
    gap: metrics.space.md,
    paddingVertical: metrics.space.sm,
    alignItems: "center",
  },
  copy: { flex: 1, gap: metrics.space.xs },
  invalid: { paddingLeft: metrics.space.xxl, paddingBottom: metrics.space.sm },
});
