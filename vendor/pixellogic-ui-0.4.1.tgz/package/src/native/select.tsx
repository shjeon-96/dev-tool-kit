import { forwardRef, type ComponentProps, type ComponentRef } from "react";
import { Select as HeroSelect } from "heroui-native/select";
import { FadeIn, FadeOut, ReduceMotion } from "react-native-reanimated";
import { metrics } from "../generated/tokens";

type SelectContentProps = ComponentProps<typeof HeroSelect.Content>;
type SelectDialogContentProps = Extract<
  SelectContentProps,
  { presentation: "dialog" }
>;
type SelectPopoverContentProps = Extract<
  SelectContentProps,
  { presentation: "popover" }
>;

const dialogAnimation = {
  entering: FadeIn.duration(metrics.duration.normal).reduceMotion(
    ReduceMotion.System,
  ),
  exiting: FadeOut.duration(metrics.duration.fast).reduceMotion(
    ReduceMotion.System,
  ),
} satisfies NonNullable<SelectDialogContentProps["animation"]>;

const popoverAnimation = {
  entering: FadeIn.duration(metrics.duration.fast).reduceMotion(
    ReduceMotion.System,
  ),
  exiting: FadeOut.duration(metrics.duration.fast).reduceMotion(
    ReduceMotion.System,
  ),
} satisfies NonNullable<SelectPopoverContentProps["animation"]>;

const Content = forwardRef<
  ComponentRef<typeof HeroSelect.Content>,
  SelectContentProps
>((props, ref) => {
  if (props.presentation === "bottom-sheet")
    return <HeroSelect.Content ref={ref} {...props} />;

  const { animation, ...rest } = props;
  return (
    <HeroSelect.Content
      ref={ref}
      {...rest}
      animation={
        animation ??
        (props.presentation === "dialog" ? dialogAnimation : popoverAnimation)
      }
    />
  );
});

Content.displayName = "PixelLogicSelectContent";

export const Select = Object.assign(HeroSelect, { Content });
