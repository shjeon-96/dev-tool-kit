import { StyleSheet, View } from "react-native";
import { useEffect, useRef, type ReactNode } from "react";
import Animated, {
  FadeIn,
  FadeOut,
  LinearTransition,
  ReduceMotion,
} from "react-native-reanimated";
import { BrandState, BrandText, Button, Spinner } from "./components";
import { metrics } from "../generated/tokens";
const listItemLayoutAnimation = LinearTransition.duration(
  metrics.duration.fast,
).reduceMotion(ReduceMotion.System);
export type DataListEndReachedInfo = { distanceFromEnd: number };
export interface DataListProps<T> {
  accessibilityLabel?: string;
  data: readonly T[];
  getItemId: (item: T) => string;
  renderItem: (item: T, index: number) => ReactNode;
  /** renderItem·header·footer가 data 외부 상태를 읽을 때 갱신 기준으로 사용해요. */
  extraData?: unknown;
  /** 첫 진입에서 목록 자체를 대체하는 loading 상태예요. */
  loading?: boolean;
  /** 목록 영역 안에 보여 줄 사용자용 오류 문구예요. */
  error?: string;
  onRetry?: () => void;
  /** 재시도 요청 중 버튼을 busy/disabled로 유지해요. */
  retrying?: boolean;
  /** 기존 행을 유지하면서 오프라인 안내를 상단에 추가해요. */
  offline?: boolean;
  offlineTitle?: string;
  offlineDescription?: string;
  offlineAction?: ReactNode;
  /** pull-to-refresh 중 기존 행을 유지하고 busy semantics를 전달해요. */
  refreshing?: boolean;
  onRefresh?: () => void;
  /** 끝에서 더 불러오는 동안 기존 행과 footer를 함께 유지해요. */
  loadingMore?: boolean;
  /** false이면 같은 끝 위치에서 더 요청하지 않아요. */
  hasMore?: boolean;
  /** 끝과의 거리 정보를 받아 prefetch/pagination 정책을 실행해요. */
  onEndReached?: (info: DataListEndReachedInfo) => void;
  header?: ReactNode;
  emptyTitle?: string;
  emptyDescription?: string;
  emptyAction?: ReactNode;
}
export function DataList<T>({
  accessibilityLabel = "목록",
  data,
  getItemId,
  renderItem,
  extraData,
  loading,
  error,
  onRetry,
  retrying = false,
  offline = false,
  offlineTitle = "오프라인이에요",
  offlineDescription = "마지막으로 불러온 내용을 보여 드려요.",
  offlineAction,
  refreshing = false,
  onRefresh,
  loadingMore = false,
  hasMore = true,
  onEndReached,
  header,
  emptyTitle = "아직 항목이 없어요",
  emptyDescription,
  emptyAction,
}: DataListProps<T>) {
  const refreshLock = useRef(false),
    retryLock = useRef(false),
    endReachedLock = useRef(false);
  useEffect(() => {
    if (!refreshing) refreshLock.current = false;
  }, [refreshing]);
  useEffect(() => {
    if (!retrying) retryLock.current = false;
  }, [retrying]);
  useEffect(() => {
    if (!loadingMore) endReachedLock.current = false;
  }, [data.length, hasMore, loadingMore]);
  function handleRefresh() {
    if (refreshing || refreshLock.current || !onRefresh) return;
    refreshLock.current = true;
    onRefresh();
  }
  function handleEndReached(info: DataListEndReachedInfo) {
    if (!hasMore || loadingMore || endReachedLock.current || !onEndReached)
      return;
    endReachedLock.current = true;
    onEndReached(info);
  }
  function handleRetry() {
    if (retrying || retryLock.current || !onRetry) return;
    retryLock.current = true;
    onRetry();
  }
  const errorState = error ? (
    <BrandState
      kind="error"
      title={error}
      compact
      action={
        onRetry && (
          <Button isLoading={retrying} onPress={handleRetry}>
            다시 시도해요
          </Button>
        )
      }
    />
  ) : null;
  if (loading)
    return (
      <BrandState kind="loading" title="목록을 불러오는 중이에요" compact />
    );
  if (error && !data.length) return errorState;
  const offlineState = offline ? (
    <BrandState
      kind="offline"
      title={offlineTitle}
      description={offlineDescription}
      compact={data.length > 0}
      action={
        offlineAction ??
        (data.length === 0 && onRefresh ? (
          <Button isLoading={refreshing} onPress={handleRefresh}>
            다시 불러와요
          </Button>
        ) : undefined)
      }
    />
  ) : null;
  if (offline && data.length === 0)
    return <View style={styles.emptyState}>{offlineState}</View>;
  return (
    <Animated.FlatList
      data={data}
      accessibilityRole="list"
      accessibilityLabel={accessibilityLabel}
      accessibilityState={{ busy: refreshing || loadingMore || retrying }}
      style={styles.list}
      keyExtractor={getItemId}
      extraData={extraData}
      itemLayoutAnimation={listItemLayoutAnimation}
      renderItem={({ item, index }) => <View>{renderItem(item, index)}</View>}
      ListHeaderComponent={
        errorState || offlineState || header ? (
          <View>
            {errorState || offlineState}
            {header}
          </View>
        ) : null
      }
      ListEmptyComponent={
        <BrandState
          kind="empty"
          compact
          title={emptyTitle}
          description={emptyDescription}
          action={emptyAction}
        />
      }
      ListFooterComponent={
        loadingMore ? (
          <Animated.View
            style={styles.loadingMore}
            collapsable={false}
            accessible
            accessibilityRole="progressbar"
            accessibilityLabel="더 불러오는 중이에요"
            accessibilityState={{ busy: true }}
            entering={FadeIn.duration(metrics.duration.fast).reduceMotion(
              ReduceMotion.System,
            )}
            exiting={FadeOut.duration(metrics.duration.fast).reduceMotion(
              ReduceMotion.System,
            )}
          >
            <Spinner
              size="sm"
              accessibilityElementsHidden
              importantForAccessibility="no-hide-descendants"
            />
            <BrandText variant="label" muted>
              더 불러오는 중이에요
            </BrandText>
          </Animated.View>
        ) : null
      }
      keyboardShouldPersistTaps="handled"
      contentContainerStyle={[
        styles.content,
        !data.length && styles.emptyContent,
      ]}
      refreshing={refreshing}
      onRefresh={refreshing || !onRefresh ? undefined : handleRefresh}
      onEndReached={
        !data.length || !hasMore || loadingMore || !onEndReached
          ? undefined
          : handleEndReached
      }
      onEndReachedThreshold={0.3}
    />
  );
}
const styles = StyleSheet.create({
  list: { flex: 1 },
  content: { paddingBottom: metrics.space.xxl },
  emptyContent: { flexGrow: 1 },
  emptyState: {
    flex: 1,
    justifyContent: "center",
    padding: metrics.space.page,
  },
  loadingMore: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: metrics.space.sm,
    paddingVertical: metrics.space.lg,
  },
});
