import { useEffect, useRef, useState } from "react";
import { StyleSheet, View } from "react-native";
import Animated, {
  FadeIn,
  FadeOut,
  ReduceMotion,
} from "react-native-reanimated";
import Svg, {
  Line,
  Path,
  Rect,
  Text as SvgText,
  Circle,
} from "react-native-svg";
import {
  chartGeometry,
  type ChartKind,
  type ChartPoint,
} from "../shared/chart";
import { metrics, nativeFontFamily } from "../generated/tokens";
import { BrandText, BrandState, Button, Stack, ListRow } from "./components";
import { useTheme } from "./provider";
import { withBrandErrorBoundary } from "./error-boundary";
function TrendChartView({
  label,
  unit,
  data,
  kind = "line",
  loading,
  error,
  onRetry,
  retrying = false,
}: {
  label: string;
  unit: string;
  data: ChartPoint[];
  kind?: ChartKind;
  loading?: boolean;
  error?: string;
  onRetry?: () => void;
  retrying?: boolean;
}) {
  const [width, setWidth] = useState(0),
    [expanded, setExpanded] = useState(false),
    retryLock = useRef(false);
  useEffect(() => {
    if (!retrying) retryLock.current = false;
  }, [retrying]);
  function handleRetry() {
    if (retrying || retryLock.current || !onRetry) return;
    retryLock.current = true;
    onRetry();
  }
  const { colors } = useTheme(),
    padding = metrics.space.xl,
    height = metrics.size.control * 4;
  const geometry = chartGeometry(
    data,
    Math.max(1, width - padding * 2),
    height,
  );
  if (loading)
    return (
      <BrandState
        kind="loading"
        title={`${label}을 불러오는 중이에요`}
        compact
      />
    );
  if (error)
    return (
      <BrandState
        kind="error"
        title={error}
        compact
        action={
          onRetry && (
            <Button isLoading={retrying} onPress={handleRetry}>
              다시 시도해요
            </Button>
          )
        }
      />
    );
  if (!geometry.hasData)
    return <BrandState kind="empty" title="표시할 데이터가 없어요" compact />;
  const segments: string[][] = [];
  geometry.points.forEach((point) => {
    if (point.y === null) segments.push([]);
    else {
      if (!segments.length) segments.push([]);
      segments[segments.length - 1]!.push(
        `${point.x + padding},${point.y + padding}`,
      );
    }
  });
  return (
    <Stack gap="sm">
      <View style={styles.heading}>
        <BrandText variant="heading">{label}</BrandText>
        <BrandText variant="caption" muted>
          단위: {unit}
        </BrandText>
      </View>
      <View
        onLayout={(event) => setWidth(event.nativeEvent.layout.width)}
        style={styles.canvas}
        accessibilityRole="image"
        accessibilityLabel={`${label}. ${data.map((point) => `${point.label}: ${point.value === null ? "기록 없음" : `${point.value}${unit}`}`).join(", ")}`}
      >
        {width > 0 && (
          <Svg width={width} height={height + padding * 2} accessible={false}>
            <Line
              x1={padding}
              y1={geometry.baseline + padding}
              x2={width - padding}
              y2={geometry.baseline + padding}
              stroke={colors.border}
            />
            {kind === "bar"
              ? geometry.points.map((point, index) =>
                  point.y !== null ? (
                    <Rect
                      key={point.label}
                      x={
                        padding +
                        ((index + 0.2) * (width - padding * 2)) / data.length
                      }
                      y={Math.min(point.y!, geometry.baseline) + padding}
                      width={((width - padding * 2) / data.length) * 0.6}
                      height={Math.abs(geometry.baseline - point.y!)}
                      rx={metrics.space.xs}
                      fill={colors.chart}
                    />
                  ) : null,
                )
              : segments
                  .filter((segment) => segment.length)
                  .map((segment, index) => (
                    <Path
                      key={index}
                      d={`M ${segment.join(" L ")}${kind === "area" ? ` L ${segment[segment.length - 1]!.split(",")[0]},${geometry.baseline + padding} L ${segment[0]!.split(",")[0]},${geometry.baseline + padding} Z` : ""}`}
                      stroke={colors.chart}
                      strokeWidth={metrics.stroke}
                      fill={kind === "area" ? colors.chartSoft : "none"}
                    />
                  ))}
            {kind !== "bar" &&
              geometry.points
                .filter((point) => point.y !== null)
                .map((point) => (
                  <Circle
                    key={point.label}
                    cx={point.x + padding}
                    cy={point.y! + padding}
                    r={metrics.space.xs}
                    fill={colors.chart}
                  />
                ))}
            <SvgText
              x={padding}
              y={height + padding * 2 - 2}
              fontFamily={nativeFontFamily}
              fontSize={metrics.fontSize.caption}
              fill={colors.mutedForeground}
            >
              {data[0]?.label}
            </SvgText>
            <SvgText
              x={width - padding}
              y={height + padding * 2 - 2}
              textAnchor="end"
              fontFamily={nativeFontFamily}
              fontSize={metrics.fontSize.caption}
              fill={colors.mutedForeground}
            >
              {data[data.length - 1]?.label}
            </SvgText>
            <SvgText
              x={padding}
              y={metrics.space.md}
              fontFamily={nativeFontFamily}
              fontSize={metrics.fontSize.caption}
              fill={colors.mutedForeground}
            >
              {geometry.max}
              {unit}
            </SvgText>
          </Svg>
        )}
      </View>
      <Button
        variant="ghost"
        onPress={() => setExpanded(!expanded)}
        accessibilityState={{ expanded }}
      >
        {expanded ? "데이터를 접어요" : "데이터 값을 봐요"}
      </Button>
      {expanded && (
        <Animated.View
          collapsable={false}
          entering={FadeIn.duration(metrics.duration.fast).reduceMotion(
            ReduceMotion.System,
          )}
          exiting={FadeOut.duration(metrics.duration.fast).reduceMotion(
            ReduceMotion.System,
          )}
        >
          {data.map((point) => (
            <ListRow
              key={point.label}
              title={point.label}
              description={
                point.value === null ? "기록 없음" : `${point.value}${unit}`
              }
            />
          ))}
        </Animated.View>
      )}
    </Stack>
  );
}
const styles = StyleSheet.create({
  heading: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: metrics.space.sm,
  },
  canvas: { width: "100%", minHeight: metrics.size.control * 5 },
});

export const TrendChart = withBrandErrorBoundary(
  TrendChartView,
  "차트를 표시할 수 없어요",
);
