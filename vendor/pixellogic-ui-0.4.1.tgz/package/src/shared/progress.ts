export interface GoalData {
  value: number;
  target: number;
}
export interface GoalProps extends GoalData {
  label: string;
  unit: string;
  locale?: string;
}
export function goalProgress({ value, target }: GoalData) {
  if (
    !Number.isFinite(value) ||
    value < 0 ||
    !Number.isFinite(target) ||
    target <= 0
  ) {
    throw new RangeError(
      "진행 값은 0 이상, 목표는 0보다 큰 유한한 수여야 해요.",
    );
  }
  const ratio = value / target;
  const percentage =
    value < target
      ? Math.min(Math.round(ratio * 100), 99)
      : Math.round(ratio * 100);
  if (!Number.isFinite(percentage))
    throw new RangeError("진행률을 표현할 수 있는 값의 범위를 벗어났어요.");
  // 시각적 링만 한 바퀴로 제한하고 실제 초과 값과 달성률은 보존해요.
  return {
    fraction: Math.min(ratio, 1),
    percentage,
    remaining: Math.max(target - value, 0),
    complete: value >= target,
  };
}
export function formatMetric(value: number, locale = "ko-KR") {
  if (!Number.isFinite(value))
    throw new RangeError("표시할 값은 유한한 수여야 해요.");
  return new Intl.NumberFormat(locale, { maximumFractionDigits: 2 }).format(
    value,
  );
}
export function goalValueText({ value, target, unit, locale }: GoalProps) {
  return `${formatMetric(value, locale)} / ${formatMetric(target, locale)} ${unit}`;
}
