import { Component, type ReactNode } from "react";

export const DEFAULT_ERROR_DESCRIPTION = "잠시 후 다시 시도해 주세요.";

export interface ErrorBoundaryProps {
  children: ReactNode;
  fallback: (error: Error, reset: () => void) => ReactNode;
  onError?: (error: Error) => void;
}

export class ErrorBoundary extends Component<
  ErrorBoundaryProps,
  { error: Error | null }
> {
  state: { error: Error | null } = { error: null };

  reset = () => {
    if (this.state.error) this.setState({ error: null });
  };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error) {
    this.props.onError?.(error);
  }

  componentDidUpdate(previous: ErrorBoundaryProps) {
    // 데이터가 고쳐져 새 children이 오거나 사용자가 재시도하면 다시 그려 봐요.
    // 그대로 실패하면 곧바로 대체 화면으로 돌아오고, 같은 children에서는 순환하지 않아요.
    if (this.state.error && previous.children !== this.props.children)
      this.setState({ error: null });
  }

  render() {
    return this.state.error
      ? this.props.fallback(this.state.error, this.reset)
      : this.props.children;
  }
}
