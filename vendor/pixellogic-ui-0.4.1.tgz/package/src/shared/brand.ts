export const brandStates = {
  empty: { asset: "empty", tone: "neutral" },
  "no-results": { asset: "no-results", tone: "neutral" },
  loading: { asset: "loading", tone: "neutral" },
  error: { asset: "error", tone: "danger" },
  offline: { asset: "offline", tone: "warning" },
  success: { asset: "success", tone: "success" },
} as const;
export type BrandStateKind = keyof typeof brandStates;
export type SemanticTone =
  "neutral" | "success" | "warning" | "danger" | "info";
export type MascotSize = "small" | "medium" | "large";
