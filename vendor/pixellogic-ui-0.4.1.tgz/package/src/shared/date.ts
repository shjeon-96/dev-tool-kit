export function parseLocalDate(value: string): Date {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) throw new RangeError("날짜는 YYYY-MM-DD 형식이어야 해요.");
  const year = Number(match[1]),
    month = Number(match[2]),
    day = Number(match[3]);
  const date = new Date(0);
  // 날짜만 다루는 값이 시간대와 자정의 시계 변경 때문에 전날로 이동하지 않도록 정오를 써요.
  date.setHours(12, 0, 0, 0);
  date.setFullYear(year, month - 1, day);
  if (
    date.getFullYear() !== year ||
    date.getMonth() !== month - 1 ||
    date.getDate() !== day
  )
    throw new RangeError("존재하지 않는 날짜예요.");
  return date;
}
export function toLocalDate(date: Date): string {
  if (!Number.isFinite(date.getTime()))
    throw new RangeError("유효한 날짜가 필요해요.");
  return `${String(date.getFullYear()).padStart(4, "0")}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
export function displayDate(value: string, locale = "ko-KR") {
  return new Intl.DateTimeFormat(locale, {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(parseLocalDate(value));
}
export interface ChoiceOption {
  value: string;
  label: string;
  disabled?: boolean;
}
export function validateChoices(
  options: readonly ChoiceOption[],
  value?: string,
) {
  const values = new Set(options.map((option) => option.value));
  if (values.size !== options.length || values.has(""))
    throw new RangeError("선택지 값은 비어 있지 않고 서로 달라야 해요.");
  if (value !== undefined && !values.has(value))
    throw new RangeError("현재 값에 해당하는 선택지가 없어요.");
}
