import { useEffect, useRef, useState } from "react";
export interface WizardOptions {
  stepCount: number;
  validateStep?: (step: number) => boolean | Promise<boolean>;
  onComplete: () => void | Promise<void>;
  onError?: (error: unknown) => void;
}
export function useWizard({
  stepCount,
  validateStep,
  onComplete,
  onError,
}: WizardOptions) {
  if (!Number.isInteger(stepCount) || stepCount < 1)
    throw new RangeError("한 개 이상의 단계가 필요해요.");
  const [step, setStep] = useState(0),
    [busy, setBusy] = useState(false),
    [completed, setCompleted] = useState(false),
    [failed, setFailed] = useState(false);
  const locked = useRef(false),
    mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  const current = Math.min(step, stepCount - 1);
  async function next() {
    // React 렌더 이전에 들어오는 중복 제출도 같은 잠금으로 막아요.
    if (locked.current || completed) return;
    locked.current = true;
    setBusy(true);
    setFailed(false);
    let completedOperation = false;
    try {
      const valid = validateStep ? await validateStep(current) : true;
      if (!valid) return;
      if (!mounted.current) return;
      if (current < stepCount - 1) setStep(current + 1);
      else {
        await onComplete();
        completedOperation = true;
        if (mounted.current) setCompleted(true);
      }
    } catch (error) {
      if (mounted.current) {
        setFailed(true);
        onError?.(error);
      }
    } finally {
      if (!completedOperation) locked.current = false;
      if (mounted.current) setBusy(false);
    }
  }
  return {
    current,
    busy,
    completed,
    failed,
    next,
    previous: () => {
      if (!locked.current && !completed) setStep(Math.max(0, current - 1));
    },
  };
}
