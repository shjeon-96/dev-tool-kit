export interface ChartPoint {
  label: string;
  value: number | null;
}
export type ChartKind = "line" | "area" | "bar";
export function chartDomain(data: readonly ChartPoint[]) {
  const labels = new Set<string>();
  const values: number[] = [];
  for (const point of data) {
    if (!point.label.trim() || labels.has(point.label))
      throw new RangeError("차트 라벨은 비어 있지 않고 서로 달라야 해요.");
    labels.add(point.label);
    if (point.value !== null) {
      if (!Number.isFinite(point.value))
        throw new RangeError("차트 값은 유한한 수 또는 null이어야 해요.");
      values.push(point.value);
    }
  }
  const min = Math.min(0, ...values),
    max = Math.max(0, ...values);
  if (!Number.isFinite(max - min))
    throw new RangeError("차트 범위를 표현할 수 없어요.");
  return { min, max: max === min ? min + 1 : max, hasData: values.length > 0 };
}
export function chartGeometry(
  data: readonly ChartPoint[],
  width: number,
  height: number,
) {
  const domain = chartDomain(data);
  const x = (index: number) =>
    data.length < 2 ? width / 2 : (index / (data.length - 1)) * width;
  const y = (value: number) =>
    height - ((value - domain.min) / (domain.max - domain.min)) * height;
  return {
    ...domain,
    baseline: y(0),
    points: data.map((point, index) => ({
      ...point,
      x: x(index),
      y: point.value === null ? null : y(point.value),
    })),
  };
}
