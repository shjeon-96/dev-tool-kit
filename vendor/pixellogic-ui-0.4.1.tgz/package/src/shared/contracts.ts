import type { ReactNode } from "react";
import type { BrandStateKind, SemanticTone } from "./brand";
import type { ChoiceOption } from "./date";

// web과 native가 같은 이름으로 내보내는 컴포넌트는 여기 적힌 props를 똑같이 받아요.
// 플랫폼 고유 props(onClick vs onPress, className vs style)는 각자 더해요.
// 한쪽에만 prop이 생기면 src/contracts.assert.ts에서 타입 오류가 나요.

export interface StatusBadgeContract {
  tone?: SemanticTone;
  children: ReactNode;
}

export interface ListRowContract {
  title: string;
  description?: string;
  leading?: ReactNode;
  trailing?: ReactNode;
  selected?: boolean;
  disabled?: boolean;
}

export interface SectionContract {
  title: string;
  description?: string;
  action?: ReactNode;
  children: ReactNode;
}

export interface BrandStateContract {
  kind: BrandStateKind;
  title: string;
  description?: string;
  action?: ReactNode;
  compact?: boolean;
}

export interface StepperContract {
  steps: readonly string[];
  current: number;
}

export interface ComboboxContract {
  label: string;
  options: readonly ChoiceOption[];
  value?: string;
  onValueChange: (value: string | undefined) => void;
  description?: string;
  error?: string;
  clearable?: boolean;
}

export interface DatePickerContract {
  label: string;
  value?: string;
  onValueChange: (value: string | undefined) => void;
  min?: string;
  max?: string;
  description?: string;
  error?: string;
}

export interface TextFieldContract {
  label: string;
  description?: string;
  error?: string;
  isRequired?: boolean;
}

export interface TextAreaFieldContract extends TextFieldContract {}

export interface TrendChartContract {
  label: string;
  unit: string;
  loading?: boolean;
  error?: string;
  onRetry?: () => void;
  retrying?: boolean;
}
