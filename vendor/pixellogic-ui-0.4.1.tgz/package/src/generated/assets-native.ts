// 공용 에셋 카탈로그에서 생성해요.
import type { ImageSourcePropType } from 'react-native';
export type MascotAsset = 'neutral' | 'welcome' | 'empty' | 'no-results' | 'loading' | 'error' | 'offline' | 'success';
export const mascotSources: Record<MascotAsset, ImageSourcePropType> = {
  'neutral': require('../../assets/neutral.png'),
  'welcome': require('../../assets/welcome.png'),
  'empty': require('../../assets/empty.png'),
  'no-results': require('../../assets/no-results.png'),
  'loading': require('../../assets/loading.png'),
  'error': require('../../assets/error.png'),
  'offline': require('../../assets/offline.png'),
  'success': require('../../assets/success.png'),
};
