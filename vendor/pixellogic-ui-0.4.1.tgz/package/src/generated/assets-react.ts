// 공용 에셋 카탈로그에서 생성해요. 번들러가 실제 PNG를 배포물에 포함하도록 import해요.
import image0 from '../../assets/neutral.png';
import image1 from '../../assets/welcome.png';
import image2 from '../../assets/empty.png';
import image3 from '../../assets/no-results.png';
import image4 from '../../assets/loading.png';
import image5 from '../../assets/error.png';
import image6 from '../../assets/offline.png';
import image7 from '../../assets/success.png';
export type MascotAsset = 'neutral' | 'welcome' | 'empty' | 'no-results' | 'loading' | 'error' | 'offline' | 'success';
export const mascotSources: Record<MascotAsset, string> = {
  'neutral': image0,
  'welcome': image1,
  'empty': image2,
  'no-results': image3,
  'loading': image4,
  'error': image5,
  'offline': image6,
  'success': image7,
};
