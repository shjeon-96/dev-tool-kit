// 공용 에셋 카탈로그에서 생성해요. React 배포물은 packages/ui/dist에서 실행돼요.
const image0 = new URL('../assets/neutral.png', import.meta.url).href;
const image1 = new URL('../assets/welcome.png', import.meta.url).href;
const image2 = new URL('../assets/empty.png', import.meta.url).href;
const image3 = new URL('../assets/no-results.png', import.meta.url).href;
const image4 = new URL('../assets/loading.png', import.meta.url).href;
const image5 = new URL('../assets/error.png', import.meta.url).href;
const image6 = new URL('../assets/offline.png', import.meta.url).href;
const image7 = new URL('../assets/success.png', import.meta.url).href;
export type MascotAsset = 'neutral' | 'welcome' | 'empty' | 'no-results' | 'loading' | 'error' | 'offline' | 'success';
export const mascotSources: Record<MascotAsset, string> = {
  'neutral': image0,
  'welcome': image1,
  'empty': image2,
  'no-results': image3,
  'loading': image4,
  'error': image5,
  'offline': image6,
  'success': image7,
};
