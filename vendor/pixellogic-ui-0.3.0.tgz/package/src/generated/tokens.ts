// brand.tokens.json에서 생성해요. 이 파일을 직접 수정하지 마세요.
export const colors = {
  "light": {
    "background": "#fffbf6",
    "foreground": "#39281f",
    "surface": "#ffffff",
    "surfaceForeground": "#39281f",
    "muted": "#f8eee7",
    "mutedForeground": "#74665c",
    "primary": "#f3aa8c",
    "primaryForeground": "#39281f",
    "primaryPressed": "#efa07f",
    "secondary": "#fce8dd",
    "secondaryForeground": "#39281f",
    "border": "#dac9ba",
    "input": "#af9581",
    "focus": "#925238",
    "disabled": "#eee7e1",
    "disabledForeground": "#887e75",
    "success": "#52734d",
    "successSoft": "#edf3e8",
    "danger": "#aa4636",
    "dangerSoft": "#fbe8e2",
    "warning": "#8a601c",
    "warningSoft": "#fff0c9",
    "info": "#4e6675",
    "infoSoft": "#eaf0f3",
    "progress": "#be6849",
    "chart": "#4e6675",
    "chartSoft": "#eaf0f3"
  },
  "dark": {
    "background": "#241d19",
    "foreground": "#fff9f0",
    "surface": "#302722",
    "surfaceForeground": "#fff9f0",
    "muted": "#3d312a",
    "mutedForeground": "#c4afa0",
    "primary": "#f3aa8c",
    "primaryForeground": "#39281f",
    "primaryPressed": "#efa07f",
    "secondary": "#51372b",
    "secondaryForeground": "#ffe7d9",
    "border": "#665044",
    "input": "#93735f",
    "focus": "#f3aa8c",
    "disabled": "#443a33",
    "disabledForeground": "#a18b7b",
    "success": "#b8d4a7",
    "successSoft": "#293725",
    "danger": "#ffb4a4",
    "dangerSoft": "#4b2b24",
    "warning": "#f1cf8c",
    "warningSoft": "#45371e",
    "info": "#bdcfdd",
    "infoSoft": "#29333b",
    "progress": "#f3aa8c",
    "chart": "#bdcfdd",
    "chartSoft": "#29333b"
  }
} as const;
export const metrics = {
  "space": {
    "xs": 4,
    "sm": 8,
    "md": 12,
    "lg": 16,
    "page": 20,
    "xl": 24,
    "xxl": 32,
    "section": 48,
    "hero": 64
  },
  "radius": {
    "sm": 8,
    "control": 16,
    "card": 20,
    "dialog": 24,
    "pill": 9999
  },
  "size": {
    "control": 48,
    "compact": 40,
    "row": 56,
    "icon": 20,
    "iconLarge": 24,
    "mascotSmall": 64,
    "mascotMedium": 112,
    "mascotLarge": 160,
    "content": 1200,
    "progress": 160,
    "progressStroke": 12,
    "chart": 240,
    "sidebar": 240,
    "sidebarMobile": 288,
    "calendarDay": 40
  },
  "fontSize": {
    "display": 31,
    "title": 25,
    "heading": 20,
    "body": 16,
    "label": 14,
    "caption": 13,
    "metric": 48
  },
  "fontWeight": {
    "regular": 400,
    "medium": 500,
    "semibold": 600,
    "bold": 700
  },
  "lineHeight": {
    "tight": 1.15,
    "snug": 1.4,
    "normal": 1.5,
    "relaxed": 1.6
  },
  "duration": {
    "fast": 150,
    "normal": 200,
    "loop": 900
  },
  "easing": {
    "standard": [
      0.2,
      0,
      0,
      1
    ],
    "decelerate": [
      0,
      0,
      0,
      1
    ]
  },
  "stroke": 1.75
} as const;
export type ColorRole = keyof typeof colors.light;
export type ColorMode = keyof typeof colors;
