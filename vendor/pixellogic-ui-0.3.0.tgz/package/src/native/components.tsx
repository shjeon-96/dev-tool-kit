import {
  forwardRef,
  useId,
  type ComponentProps,
  type ComponentRef,
  type ReactNode,
} from "react";
import {
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
  type TextProps,
  type ViewProps,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Button as HeroButton,
  type ButtonRootProps,
} from "heroui-native/button";
import { Input } from "heroui-native/input";
import { TextField as HeroTextField } from "heroui-native/text-field";
import { Label } from "heroui-native/label";
import { Description } from "heroui-native/description";
import { FieldError } from "heroui-native/field-error";
import { Spinner as HeroSpinner } from "heroui-native/spinner";
import { Skeleton as HeroSkeleton } from "heroui-native/skeleton";
import { ControlField } from "heroui-native/control-field";
import {
  PressableFeedback,
  type PressableFeedbackProps,
} from "heroui-native/pressable-feedback";
import { Checkbox } from "./checkbox";
import { Switch } from "./switch";
import { ListGroup } from "heroui-native/list-group";
import { tv } from "tailwind-variants";
import {
  CircleCheck,
  CircleAlert,
  TriangleAlert,
  Info,
  ChevronRight,
  ArrowLeft,
  Check,
  type LucideIcon,
} from "lucide-react-native";
import { mascotSources, type MascotAsset } from "../generated/assets-native";
import { metrics } from "../generated/tokens";
import {
  brandStates,
  type BrandStateKind,
  type MascotSize,
} from "../shared/brand";
import type {
  ListRowContract,
  SectionContract,
  StatusBadgeContract,
} from "../shared/contracts";
import { useTheme } from "./provider";
import Animated, {
  FadeIn,
  FadeOut,
  ReduceMotion,
} from "react-native-reanimated";

const buttonRecipe = tv({
  slots: {
    base: "rounded-pl-control min-h-pl-control",
    label: "text-base font-semibold",
  },
  variants: {
    fullWidth: { true: { base: "w-full" } },
    intent: {
      primary: { label: "text-accent-foreground" },
      secondary: { label: "text-foreground" },
      outline: { label: "text-foreground" },
      ghost: { label: "text-foreground" },
      danger: { label: "text-danger-foreground" },
    },
  },
  defaultVariants: { intent: "primary" },
});
type ButtonAnimation = Extract<
  ButtonRootProps,
  { feedbackVariant?: "scale-highlight" }
>["animation"];
const buttonAnimation = {
  scale: { timingConfig: { duration: metrics.duration.fast } },
  highlight: {
    opacity: { timingConfig: { duration: metrics.duration.fast } },
  },
} satisfies NonNullable<ButtonAnimation>;
const listRowAnimation = {
  scale: { timingConfig: { duration: metrics.duration.fast } },
} satisfies NonNullable<PressableFeedbackProps["animation"]>;
export type ButtonProps = Omit<
  ComponentProps<typeof HeroButton>,
  "children" | "variant" | "feedbackVariant" | "animation"
> & {
  children: ReactNode;
  variant?: "primary" | "secondary" | "outline" | "ghost" | "danger";
  isLoading?: boolean;
  loadingLabel?: string;
  fullWidth?: boolean;
  startContent?: ReactNode;
  endContent?: ReactNode;
  animation?: ButtonAnimation;
};
export const Button = forwardRef<ComponentRef<typeof HeroButton>, ButtonProps>(
  function Button(
    {
      children,
      variant = "primary",
      isLoading = false,
      loadingLabel = "처리 중이에요",
      isDisabled,
      fullWidth,
      startContent,
      endContent,
      className,
      accessibilityState,
      animation = buttonAnimation,
      ...props
    },
    ref,
  ) {
    const recipe = buttonRecipe({ intent: variant, fullWidth });
    const { colors } = useTheme();
    return (
      <HeroButton
        ref={ref}
        {...props}
        feedbackVariant="scale-highlight"
        animation={animation}
        variant={variant}
        isDisabled={isDisabled || isLoading}
        accessibilityState={{
          ...accessibilityState,
          disabled: isDisabled || isLoading,
          busy: isLoading,
        }}
        className={recipe.base({ className })}
        style={[
          props.style,
          isLoading
            ? { opacity: 1, backgroundColor: colors.secondary }
            : isDisabled
              ? { opacity: 1, backgroundColor: colors.disabled }
              : undefined,
        ]}
      >
        {isLoading ? (
          <HeroSpinner
            size="sm"
            accessibilityElementsHidden
            importantForAccessibility="no-hide-descendants"
          >
            <HeroSpinner.Indicator
              iconProps={{ color: colors.secondaryForeground }}
            />
          </HeroSpinner>
        ) : (
          startContent
        )}
        <HeroButton.Label
          className={recipe.label()}
          style={
            isLoading
              ? { color: colors.secondaryForeground }
              : isDisabled
                ? { color: colors.disabledForeground }
                : variant === "ghost"
                  ? { color: colors.focus }
                  : undefined
          }
        >
          {isLoading ? loadingLabel : children}
        </HeroButton.Label>
        {!isLoading && endContent}
      </HeroButton>
    );
  },
);
export type SpinnerProps = ComponentProps<typeof HeroSpinner>;
function SpinnerRoot({
  accessibilityLabel = "불러오는 중이에요",
  accessibilityRole,
  accessibilityState,
  isLoading = true,
  ...props
}: SpinnerProps) {
  return (
    <HeroSpinner
      {...props}
      isLoading={isLoading}
      accessibilityLabel={accessibilityLabel}
      accessibilityRole={accessibilityRole ?? "progressbar"}
      accessibilityState={{ ...accessibilityState, busy: isLoading }}
    />
  );
}
export const Spinner = Object.assign(SpinnerRoot, {
  Indicator: HeroSpinner.Indicator,
});
export type SkeletonProps = ComponentProps<typeof HeroSkeleton>;
export function Skeleton({
  isLoading = true,
  accessibilityElementsHidden,
  importantForAccessibility,
  animation,
  ...props
}: SkeletonProps) {
  return (
    <HeroSkeleton
      {...props}
      isLoading={isLoading}
      animation={
        animation ?? {
          shimmer: { duration: metrics.duration.loop },
          pulse: { duration: metrics.duration.loop },
        }
      }
      accessibilityElementsHidden={accessibilityElementsHidden ?? isLoading}
      importantForAccessibility={
        importantForAccessibility ??
        (isLoading ? "no-hide-descendants" : undefined)
      }
    />
  );
}
export function Icon({
  icon: Component,
  color,
  size = "default",
}: {
  icon: LucideIcon;
  color?: string;
  size?: "default" | "large";
}) {
  const { colors } = useTheme();
  return (
    <Component
      size={size === "large" ? metrics.size.iconLarge : metrics.size.icon}
      strokeWidth={metrics.stroke}
      color={color ?? colors.foreground}
      accessible={false}
    />
  );
}
export function IconButton({
  icon,
  label,
  style,
  animation = buttonAnimation,
  ...props
}: Omit<
  ComponentProps<typeof HeroButton>,
  | "children"
  | "isIconOnly"
  | "accessibilityLabel"
  | "feedbackVariant"
  | "animation"
> & { icon: LucideIcon; label: string; animation?: ButtonAnimation }) {
  return (
    <HeroButton
      {...props}
      feedbackVariant="scale-highlight"
      animation={animation}
      isIconOnly
      accessibilityLabel={label}
      style={[styles.iconButton, style, styles.iconButtonMinimum]}
    >
      <Icon icon={icon} />
    </HeroButton>
  );
}
export function BrandText({
  variant = "body",
  muted = false,
  style,
  ...props
}: TextProps & { variant?: keyof typeof metrics.fontSize; muted?: boolean }) {
  const { colors } = useTheme();
  return (
    <Text
      {...props}
      style={[
        {
          fontSize: metrics.fontSize[variant],
          lineHeight: metrics.fontSize[variant] * metrics.lineHeight.normal,
          color: muted ? colors.mutedForeground : colors.foreground,
        },
        ["display", "title", "heading", "label"].includes(variant) &&
          styles.semibold,
        style,
      ]}
    />
  );
}
export function Mascot({
  asset = "neutral",
  size = "medium",
  label,
}: {
  asset?: MascotAsset;
  size?: MascotSize;
  label?: string;
}) {
  const dimension = {
    small: metrics.size.mascotSmall,
    medium: metrics.size.mascotMedium,
    large: metrics.size.mascotLarge,
  }[size];
  return (
    <Image
      source={mascotSources[asset]}
      resizeMode="contain"
      style={{ width: dimension, height: dimension }}
      accessible={!!label}
      accessibilityLabel={label}
    />
  );
}
export type TextFieldProps = Omit<ComponentProps<typeof Input>, "isInvalid"> & {
  label: string;
  description?: string;
  error?: string;
  isDisabled?: boolean;
  isRequired?: boolean;
};
export function TextField({
  label,
  description,
  error,
  isDisabled,
  isRequired,
  nativeID,
  ...props
}: TextFieldProps) {
  const id = useId();
  return (
    <HeroTextField
      isDisabled={isDisabled}
      isInvalid={!!error}
      isRequired={isRequired}
      style={styles.field}
    >
      <Label nativeID={`${id}-label`}>{label}</Label>
      <Input
        {...props}
        nativeID={nativeID ?? id}
        clearButtonMode={
          props.clearButtonMode ?? (props.multiline ? "never" : "while-editing")
        }
        accessibilityLabel={label}
        accessibilityLabelledBy={`${id}-label`}
        accessibilityHint={
          [description, error].filter(Boolean).join(". ") || undefined
        }
        style={[styles.input, props.multiline && styles.textArea, props.style]}
      />
      {description && <Description>{description}</Description>}
      {error && (
        <Animated.View
          key={`field-error:${error}`}
          collapsable={false}
          entering={FadeIn.duration(metrics.duration.fast).reduceMotion(
            ReduceMotion.System,
          )}
          exiting={FadeOut.duration(metrics.duration.fast).reduceMotion(
            ReduceMotion.System,
          )}
        >
          <FieldError accessibilityLiveRegion="polite">{error}</FieldError>
        </Animated.View>
      )}
    </HeroTextField>
  );
}
export function TextAreaField(props: TextFieldProps) {
  return <TextField {...props} multiline textAlignVertical="top" />;
}
type ChoiceProps = {
  label: string;
  description?: string;
  isSelected: boolean;
  onSelectedChange: (selected: boolean) => void;
  isDisabled?: boolean;
};
export function CheckboxField({ label, description, ...props }: ChoiceProps) {
  return (
    <ControlField {...props} accessibilityLabel={label} style={styles.choice}>
      <ControlField.Indicator>
        <Checkbox>
          <Checkbox.Indicator />
        </Checkbox>
      </ControlField.Indicator>
      <View style={styles.grow}>
        <Label>{label}</Label>
        {description && <Description>{description}</Description>}
      </View>
    </ControlField>
  );
}
export function SwitchField({ label, description, ...props }: ChoiceProps) {
  return (
    <ControlField {...props} accessibilityLabel={label} style={styles.choice}>
      <View style={styles.grow}>
        <Label>{label}</Label>
        {description && <Description>{description}</Description>}
      </View>
      <ControlField.Indicator>
        <Switch>
          <Switch.Thumb />
        </Switch>
      </ControlField.Indicator>
    </ControlField>
  );
}
export function Stack({
  children,
  gap = "lg",
  direction = "column",
  style,
  ...props
}: ViewProps & {
  gap?: keyof typeof metrics.space;
  direction?: "column" | "row";
}) {
  return (
    <View
      {...props}
      style={[
        { gap: metrics.space[gap], flexDirection: direction },
        direction === "row" && styles.wrap,
        style,
      ]}
    >
      {children}
    </View>
  );
}
export function Section({
  title,
  description,
  action,
  children,
}: SectionContract) {
  return (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <View style={styles.grow}>
          <BrandText variant="heading" accessibilityRole="header">
            {title}
          </BrandText>
          {description && (
            <BrandText variant="label" muted>
              {description}
            </BrandText>
          )}
        </View>
        {action}
      </View>
      {children}
    </View>
  );
}
export function Screen({
  title,
  subtitle,
  children,
  action,
  onBack,
  scrollable = true,
  contentLayout,
  keyboardVerticalOffset = 0,
  keyboardDismissMode,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  action?: ReactNode;
  onBack?: () => void;
  scrollable?: boolean;
  contentLayout?: ComponentProps<typeof Animated.ScrollView>["layout"];
  keyboardVerticalOffset?: number;
  keyboardDismissMode?: ComponentProps<
    typeof ScrollView
  >["keyboardDismissMode"];
}) {
  const { colors, resolvedMode } = useTheme();
  const content = (
    <>
      <View style={styles.header}>
        {onBack && (
          <IconButton
            icon={ArrowLeft}
            label="뒤로 가요"
            variant="ghost"
            onPress={onBack}
          />
        )}
        <View style={styles.grow}>
          <BrandText variant="title" accessibilityRole="header">
            {title}
          </BrandText>
          {subtitle && (
            <BrandText variant="label" muted>
              {subtitle}
            </BrandText>
          )}
        </View>
        {action}
      </View>
      {children}
    </>
  );
  return (
    <SafeAreaView style={[styles.root, { backgroundColor: colors.background }]}>
      <StatusBar
        barStyle={resolvedMode === "dark" ? "light-content" : "dark-content"}
      />
      <KeyboardAvoidingView
        style={styles.root}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={keyboardVerticalOffset}
      >
        {scrollable && contentLayout ? (
          <Animated.ScrollView
            // Accordion 화면에서만 주변 콘텐츠도 같은 transition을 따르게 해요.
            layout={contentLayout}
            keyboardShouldPersistTaps="handled"
            keyboardDismissMode={
              keyboardDismissMode ??
              (Platform.OS === "ios" ? "interactive" : "on-drag")
            }
            contentContainerStyle={styles.screen}
          >
            {content}
          </Animated.ScrollView>
        ) : scrollable ? (
          <ScrollView
            keyboardShouldPersistTaps="handled"
            keyboardDismissMode={
              keyboardDismissMode ??
              (Platform.OS === "ios" ? "interactive" : "on-drag")
            }
            contentContainerStyle={styles.screen}
          >
            {content}
          </ScrollView>
        ) : (
          <View style={[styles.root, styles.screen]}>{content}</View>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const statusIcons = {
  neutral: Info,
  success: CircleCheck,
  warning: TriangleAlert,
  danger: CircleAlert,
  info: Info,
};
export function StatusBadge({
  tone = "neutral",
  children,
}: StatusBadgeContract) {
  const { colors } = useTheme();
  const foreground = tone === "neutral" ? colors.mutedForeground : colors[tone];
  const background = tone === "neutral" ? colors.muted : colors[`${tone}Soft`];
  return (
    <View style={[styles.badge, { backgroundColor: background }]}>
      <Icon icon={statusIcons[tone]} color={foreground} />
      <BrandText variant="caption" style={{ color: foreground }}>
        {children}
      </BrandText>
    </View>
  );
}
export function BrandState({
  kind,
  title,
  description,
  action,
  compact = false,
}: {
  kind: BrandStateKind;
  title: string;
  description?: string;
  action?: ReactNode;
  compact?: boolean;
}) {
  const state = brandStates[kind];
  return (
    <Animated.View
      key={`${kind}:${title}`}
      collapsable={false}
      entering={FadeIn.duration(metrics.duration.fast).reduceMotion(
        ReduceMotion.System,
      )}
      exiting={FadeOut.duration(metrics.duration.fast).reduceMotion(
        ReduceMotion.System,
      )}
      style={[styles.state, compact && styles.stateCompact]}
    >
      <Mascot asset={state.asset} size={compact ? "small" : "large"} />
      <View style={[styles.stateCopy, compact && styles.grow]}>
        <View
          accessible
          accessibilityRole={
            kind === "error"
              ? "alert"
              : kind === "loading"
                ? "progressbar"
                : undefined
          }
          role={kind === "error" || kind === "loading" ? undefined : "status"}
          accessibilityLabel={[title, description].filter(Boolean).join(". ")}
          accessibilityLiveRegion={kind === "error" ? "assertive" : "polite"}
          accessibilityState={{ busy: kind === "loading" }}
        >
          <View style={styles.stateTitle}>
            {kind === "loading" && (
              <HeroSpinner
                size="sm"
                accessibilityElementsHidden
                importantForAccessibility="no-hide-descendants"
              />
            )}
            <BrandText variant={compact ? "body" : "heading"}>
              {title}
            </BrandText>
          </View>
          {description && (
            <BrandText variant="label" muted>
              {description}
            </BrandText>
          )}
        </View>
        {action}
      </View>
    </Animated.View>
  );
}
export function ListRow({
  title,
  description,
  onPress,
  leading,
  trailing,
  selected,
  disabled,
}: ListRowContract & { onPress?: () => void }) {
  const item = (
    <ListGroup.Item
      onPress={onPress}
      disabled={disabled}
      accessibilityRole={onPress ? "button" : "text"}
      accessibilityLabel={[title, description].filter(Boolean).join(", ")}
      accessibilityState={{ selected, disabled }}
      style={styles.listRow}
    >
      {leading && <ListGroup.ItemPrefix>{leading}</ListGroup.ItemPrefix>}
      <ListGroup.ItemContent>
        <ListGroup.ItemTitle>{title}</ListGroup.ItemTitle>
        {description && (
          <ListGroup.ItemDescription>{description}</ListGroup.ItemDescription>
        )}
      </ListGroup.ItemContent>
      {(selected || trailing || onPress) && (
        <ListGroup.ItemSuffix>
          {selected && <Icon icon={Check} />}
          {trailing}
          {onPress && <Icon icon={ChevronRight} />}
        </ListGroup.ItemSuffix>
      )}
    </ListGroup.Item>
  );
  if (!onPress) return item;
  return (
    <PressableFeedback
      asChild
      isDisabled={disabled}
      animation={listRowAnimation}
    >
      {item}
    </PressableFeedback>
  );
}
const styles = StyleSheet.create({
  root: { flex: 1 },
  grow: { flex: 1 },
  wrap: { flexWrap: "wrap", alignItems: "center" },
  semibold: { fontWeight: metrics.fontWeight.semibold },
  iconButton: {
    width: metrics.size.control,
    height: metrics.size.control,
    borderRadius: metrics.radius.control,
  },
  iconButtonMinimum: {
    minWidth: metrics.size.control,
    minHeight: metrics.size.control,
  },
  field: { gap: metrics.space.sm },
  input: {
    minHeight: metrics.size.control,
    borderRadius: metrics.radius.control,
    fontSize: metrics.fontSize.body,
  },
  textArea: { minHeight: metrics.size.control * 3 },
  choice: {
    minHeight: metrics.size.control,
    gap: metrics.space.md,
    paddingVertical: metrics.space.sm,
  },
  section: { gap: metrics.space.lg },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: metrics.space.lg,
  },
  screen: {
    padding: metrics.space.page,
    gap: metrics.space.xxl,
    paddingBottom: metrics.space.section,
  },
  header: { flexDirection: "row", alignItems: "center", gap: metrics.space.lg },
  badge: {
    flexDirection: "row",
    alignItems: "center",
    gap: metrics.space.xs,
    borderRadius: metrics.radius.pill,
    paddingVertical: metrics.space.xs,
    paddingHorizontal: metrics.space.sm,
    alignSelf: "flex-start",
  },
  state: {
    alignItems: "center",
    gap: metrics.space.md,
    paddingVertical: metrics.space.xl,
  },
  stateCompact: { flexDirection: "row", paddingVertical: metrics.space.md },
  stateCopy: { gap: metrics.space.sm },
  stateTitle: {
    flexDirection: "row",
    alignItems: "center",
    gap: metrics.space.sm,
  },
  listRow: { minHeight: metrics.size.row },
});
