import { type ComponentProps } from "react";
import { BottomSheet as HeroBottomSheet } from "heroui-native/bottom-sheet";

type PortalProps = ComponentProps<typeof HeroBottomSheet.Portal>;

const Portal = ({
  unstable_accessibilityContainerViewIsModal = true,
  ...props
}: PortalProps) => (
  <HeroBottomSheet.Portal
    unstable_accessibilityContainerViewIsModal={
      unstable_accessibilityContainerViewIsModal
    }
    {...props}
  />
);

Portal.displayName = "PixelLogicBottomSheetPortal";

export const BottomSheet = Object.assign(HeroBottomSheet, { Portal });
